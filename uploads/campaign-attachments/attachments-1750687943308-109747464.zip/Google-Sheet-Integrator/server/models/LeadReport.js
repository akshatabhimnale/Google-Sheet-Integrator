const mongoose = require("mongoose");

const leadReportSchema = new mongoose.Schema({
  itlCode: {
    type: String,
    required: true,
    index: true,
  },
  date: {
    type: String, // OR Date, but you are storing as string like "2025-05-28"
    required: true,
    index: true,
  },
  acceptedCount: {
    type: Number,
    default: 0,
  },
  acceptedLeadIds: [String],
  rejectedCount: {
    type: Number,
    default: 0,
  },
  rejectedLeadIds: [String],
  lastUpdated: {
    type: Date,
    default: Date.now,
  },
});

const LeadReport = mongoose.model(
  "LeadReport",
  leadReportSchema,
  "lead_reports"
);

module.exports = LeadReport;
