export const COLUMNS = [
  {
    key: 'ITL',
    label: 'ITL',
    type: 'text',
    className: 'itl-column'
  },
  {
    key: 'tactic',
    label: 'Tactic',
    type: 'text'
  },
  {
    key: 'startDate',
    label: 'Start Date',
    type: 'date'
  },
  {
    key: 'deadline',
    label: 'End Date',
    type: 'date'
  },
  {
    key: 'pacing',
    label: 'Pacing',
    type: 'text'
  },
  {
    key: 'leadsBooked',
    label: 'Leads Booked',
    type: 'number',
    className: 'center-column'
  },
  {
    key: 'leadSent',
    label: 'Leads Sent',
    type: 'number',
    className: 'center-column'
  },
  {
    key: 'shortfall',
    label: 'Shortfall',
    type: 'number',
    className: 'center-column'
  }
  
];
