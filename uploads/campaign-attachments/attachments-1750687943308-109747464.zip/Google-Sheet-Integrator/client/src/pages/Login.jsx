import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import UserLogin from '../components/UserLogin';
import './Login.css';

const Login = () => {
  const navigate = useNavigate();
  const { currentUser, login } = useAuth();

  // Redirect if already logged in
  useEffect(() => {
    if (currentUser) {
      navigate('/dashboard');
    }
  }, [currentUser, navigate]);

  const handleLogin = (userData, token) => {
    login(userData, token);
    navigate('/dashboard');
  };

  return (
    <div className="login-page">
      <div className="login-background">
        <div className="floating-shapes">
          <div className="shape shape-1"></div>
          <div className="shape shape-2"></div>
          <div className="shape shape-3"></div>
        </div>
      </div>
      
      <div className="login-content">
        <UserLogin onLogin={handleLogin} />
      </div>
    </div>
  );
};

export default Login; 