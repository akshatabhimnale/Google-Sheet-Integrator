import React, { lazy, Suspense } from 'react';
import { 
  FaTimes, 
  FaCalendarAlt, 
  FaChartLine, 
  FaUsers, 
  FaLightbulb,
  FaComments,
  FaRocket,
  FaBullseye,
  FaArrowUp,
  FaCog,
  FaCheckCircle,
  FaExclamationTriangle,
  FaPause,
  FaPlay,
  FaArrowLeft,
  FaEdit,
  FaDownload,
  FaShare,
  FaSpinner
} from 'react-icons/fa';
import { useAuth } from '../contexts/AuthContext';
import './CampaignDetails.css';

// Lazy load components for better performance
const CampaignUpdatesPanel = lazy(() => import('../components/CampaignUpdatesPanel'));

const CampaignDetails = ({ campaign, onClose, allCampaigns = [] }) => {
  const { currentUser } = useAuth();

  if (!campaign) return null;

  const delivered = Number(campaign["Lead Sent"]) || 0;
  const projection = Number(campaign["Projection"]) || Number(campaign["Leads Booked"]) || 0;
  const goalPercent = projection > 0 ? Math.min(Math.round((delivered / projection) * 100), 100) : 0;

  // Use ITL as campaign ID for updates
  const campaignId = campaign["ITL"] || campaign["Campaign Name"] || "unknown";
  const campaignName = campaign["Campaign Name"] || campaign["ITL"] || "Campaign";

  // Status icon mapping
  const getStatusIcon = (status) => {
    switch (status?.toLowerCase()) {
      case 'completed':
      case 'internally completed':
        return <FaCheckCircle className="status-icon completed" />;
      case 'live':
        return <FaPlay className="status-icon live" />;
      case 'paused':
      case 'flagged':
        return <FaPause className="status-icon paused" />;
      case 'not live':
      case 'tbc':
        return <FaExclamationTriangle className="status-icon not-live" />;
      default:
        return <FaCog className="status-icon default" />;
    }
  };

  const LoadingFallback = ({ text = "Loading..." }) => (
    <div className="loading-fallback">
      <FaSpinner className="spinner" />
      <span>{text}</span>
    </div>
  );

  return (
    <div className="campaign-details-container">
      {/* Ultra Compact Header */}
      <div className="campaign-header">
        <div className="header-left">
          <button onClick={onClose} className="back-button">
            <FaArrowLeft />
          </button>
          <div className="campaign-info">
            <div className="campaign-status">
              {getStatusIcon(campaign["Status"])}
              <span>{campaign["Status"] || "Unknown"}</span>
            </div>
            <h1 className="campaign-title">{campaignName}</h1>
          </div>
        </div>

        <div className="header-metrics">
          <div className="metric-item">
            <FaBullseye className="metric-icon" />
            <div>
              <span className="metric-value">{goalPercent}%</span>
              <span className="metric-label">Goal</span>
      </div>
          </div>
          <div className="metric-item">
            <FaCheckCircle className="metric-icon" />
            <div>
              <span className="metric-value">{delivered.toLocaleString()}</span>
              <span className="metric-label">Delivered</span>
            </div>
        </div>
          <div className="metric-item">
            <FaArrowUp className="metric-icon" />
            <div>
              <span className="metric-value">{projection.toLocaleString()}</span>
              <span className="metric-label">Target</span>
            </div>
          </div>
        </div>

        <div className="header-actions">
          <button className="action-btn"><FaEdit /></button>
          <button className="action-btn"><FaShare /></button>
          <button className="action-btn primary"><FaDownload /></button>
          {currentUser && (
            <div className="user-info" title={`Logged in as ${currentUser.name}`}>
              <div className="user-avatar" style={{ backgroundColor: currentUser.avatar || '#0ea5e9' }}>
                {currentUser.name?.charAt(0).toUpperCase()}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Compact Grid Layout */}
      <div className="campaign-grid">
        {/* Left Column - Campaign Data */}
        <div className="campaign-data">
          {/* Timeline Section - Spans 2 columns */}
          <div className="data-card timeline-card">
            <div className="card-header">
              <FaCalendarAlt />
              <span>Timeline & Progress</span>
            </div>
            <div className="timeline-content">
              <div className="timeline-item">
                <span className="timeline-label">Start</span>
                <span className="timeline-value">{campaign["Start Date"] || "N/A"}</span>
              </div>
              <div className="timeline-divider"></div>
              <div className="timeline-item">
                <span className="timeline-label">End</span>
                <span className="timeline-value">{campaign["Deadline"] || "N/A"}</span>
              </div>
            </div>
            <div className="progress-section">
              <div className="progress-bar">
                <div className="progress-fill" style={{ width: `${goalPercent}%` }}></div>
              </div>
              <span className="progress-text">{goalPercent}% Complete</span>
            </div>
          </div>

          {/* Team Stats */}
          <div className="data-card team-card">
            <div className="card-header">
              <FaUsers />
              <span>Team</span>
            </div>
            <div className="team-stats">
              <div className="stat">
                <span className="stat-value">{campaign["Data count"] || 0}</span>
                <span className="stat-label">Data</span>
              </div>
              <div className="stat">
                <span className="stat-value">{campaign["Ops Count"] || 0}</span>
                <span className="stat-label">Ops</span>
              </div>
              <div className="stat">
                <span className="stat-value">{campaign["Quality Count"] || 0}</span>
                <span className="stat-label">Quality</span>
              </div>
              <div className="stat">
                <span className="stat-value">{campaign["MIS Count"] || 0}</span>
                <span className="stat-label">MIS</span>
              </div>
            </div>
          </div>

          {/* Performance */}
          <div className="data-card performance-card">
            <div className="card-header">
              <FaChartLine />
              <span>Performance</span>
            </div>
            <div className="performance-stats">
              <div className="perf-item">
                <span className="perf-label">Leads Booked</span>
                <span className="perf-value">{campaign["Leads Booked"] || 0}</span>
              </div>
              <div className="perf-item">
                <span className="perf-label">Leads Sent</span>
                <span className="perf-value">{campaign["Lead Sent"] || 0}</span>
              </div>
              <div className="perf-item">
                <span className="perf-label">Shortfall</span>
                <span className="perf-value shortfall">{campaign["Shortfall"] || 0}</span>
              </div>
              <div className="perf-item">
                <span className="perf-label">Delivery Days</span>
                <span className="perf-value">{campaign["Delivery Days"] || "N/A"}</span>
              </div>
              <div className="perf-item">
                <span className="perf-label">Pacing</span>
                <span className="perf-value">{campaign["Pacing"] || "N/A"}</span>
              </div>
            </div>
      </div>

          {/* Insights */}
          <div className="data-card insights-card">
            <div className="card-header">
              <FaLightbulb />
              <span>Insights</span>
            </div>
            <div className="insights-content">
              <div className="insight-item">
                <span className="insight-type">Ops:</span>
                <span className="insight-text">{campaign["Ops Insights"] || "No insights available"}</span>
              </div>
              <div className="insight-item">
                <span className="insight-type">Email:</span>
                <span className="insight-text">{campaign["Email insights"] || "No insights available"}</span>
              </div>
              <div className="insight-item">
                <span className="insight-type">Delivery:</span>
                <span className="insight-text">{campaign["Delivery insights"] || "No insights available"}</span>
              </div>
            </div>
      </div>

          {/* Comments */}
          <div className="data-card comments-card">
            <div className="card-header">
              <FaComments />
              <span>Comments</span>
            </div>
            <div className="comments-content">
              <div className="comment">
                <span className="comment-author">Data/Kapil:</span>
                <span className="comment-text">{campaign["Data/Kapil Comments"] || "No comments available"}</span>
              </div>
              <div className="comment">
                <span className="comment-author">CID Notes:</span>
                <span className="comment-text">{campaign["CID - Notes"] || "No notes available"}</span>
              </div>
            </div>
          </div>
      </div>

        {/* Right Column - Updates */}
        <div className="campaign-updates-column">
          {/* Campaign Updates */}
          <div className="updates-wrapper">
            <Suspense fallback={<LoadingFallback text="Loading updates..." />}>
              <CampaignUpdatesPanel 
                campaignId={campaignId}
                campaignName={campaignName}
              />
            </Suspense>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CampaignDetails;
