import React, {
  useState,
  useEffect,
  lazy,
  Suspense,
  useCallback,
  useRef,
} from "react";
import io from "socket.io-client";
import {
  FaSync,
  FaFilter,
  FaSearch,
  FaWifi,
  FaExclamationTriangle,
  FaChartPie,
  FaTable,
  FaSpinner,
  FaEye,
  FaDownload,
  FaCalendarAlt,
  FaChevronDown,
} from "react-icons/fa";
import CalendarRangePicker from "../components/CalendarRangePicker";
import { COLUMNS } from "../constants/columns";
import StatusDistributionCharts from "../components/StatusDistributionCharts";
import "./DashboardTable.css";
import axios from "axios";

// Lazy load heavy components
const PieChartWithCenterLabel = lazy(() =>
  import("../components/PieChartWithCenterLabel")
);

const DashboardTable = ({ onCampaignSelect, onCampaignsUpdate }) => {
  const [campaigns, setCampaigns] = useState([]);
  const [filteredCampaigns, setFilteredCampaigns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [connected, setConnected] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [socket, setSocket] = useState(null);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  // Column-wise filters state
  const [columnFilters, setColumnFilters] = useState({});
  const [showFilters, setShowFilters] = useState({});
  const [uniqueColumnValues, setUniqueColumnValues] = useState({});
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [deliveredCount, setDeliveredCount] = useState(null);
  const [deliveredCountLoading, setDeliveredCountLoading] = useState(false);
  const [error, setError] = useState(null);
  const filtersActiveRef = useRef(false);
  const [dateFilterDrafts, setDateFilterDrafts] = useState({});
  const [acceptedLeadCounts, setAcceptedLeadCounts] = useState({});

  useEffect(() => {
    // Connect to Socket.IO server
    const socket = io(
      process.env.REACT_APP_BACKEND_URL || "http://localhost:5000",
      {
        withCredentials: true,
      }
    );

    // Handle connection status
    socket.on("connect", () => {
      console.log("✅ Connected to Socket.IO server");
      setConnected(true);
    });

    socket.on("disconnect", () => {
      console.log("❌ Disconnected from Socket.IO server");
      setConnected(false);
    });

    // Handle real-time data updates
    socket.on("sheetDataUpdated", (newData) => {
      if (filtersActiveRef.current) {
        console.log("🚫 Skipping real-time update due to active filters");
        return;
      }

      console.log("📊 Received real-time data update:", newData.length, "rows");

      const validData = newData.filter(
        (row) => row.ITL && row.ITL.toString().trim() !== ""
      );

      setCampaigns(validData);
      setFilteredCampaigns(validData);
    });

    // Handle sync progress updates
    socket.on("syncProgress", (progress) => {
      console.log("🔄 Sync progress:", progress);
    });

    // Cleanup on unmount
    return () => {
      socket.disconnect();
    };
  }, []);

  // Separate effect for handling onCampaignsUpdate prop changes
  useEffect(() => {
    if (campaigns.length > 0) {
      onCampaignsUpdate?.(campaigns);
    }
  }, [onCampaignsUpdate, campaigns]);

  // Generate unique values when campaigns data changes
  useEffect(() => {
    if (campaigns.length === 0) return;

    const uniqueValues = {};
    COLUMNS.forEach((column) => {
      if (column.type === "date") return;

      const values = campaigns
        .map((campaign) => campaign[column.key])
        .filter((value) => value && value.toString().trim() !== "")
        .map((value) => value.toString().trim());

      uniqueValues[column.key] = [...new Set(values)].sort();
    });

    setUniqueColumnValues(uniqueValues);
  }, [campaigns]);

  useEffect(() => {
    const hasFilters =
      searchTerm?.trim() !== "" ||
      !!startDate ||
      !!endDate ||
      Object.keys(columnFilters).length > 0;

    filtersActiveRef.current = hasFilters;
  }, [searchTerm, startDate, endDate, columnFilters]);

  useEffect(() => {
    let filtered = [...campaigns];

    if (searchTerm && searchTerm.trim() !== "") {
      const searchLower = searchTerm.trim().toLowerCase();
      filtered = filtered.filter((campaign) => {
        const itl = (campaign.ITL ?? campaign.itl ?? "")
          .toString()
          .trim()
          .toLowerCase();
        return itl.includes(searchLower);
      });
    }

    // 2. Date range (global)
    if (startDate || endDate) {
      filtered = filtered.filter((campaign) => {
        const dateStr = campaign.startDate; // now always ISO
        if (!dateStr) return false;
        let valid = true;
        if (startDate) valid = valid && dateStr >= startDate;
        if (endDate) valid = valid && dateStr <= endDate;
        return valid;
      });
    }

    // 3. Column Filters
    Object.entries(columnFilters).forEach(([key, value]) => {
      if (value == null || value === "") return;
      const columnDef = COLUMNS.find((col) => col.key === key);
      if (!columnDef) return;

      // HERE is where you put it!
      if (columnDef.type === "date" && typeof value === "object") {
        // { start, end }
        filtered = filtered.filter((campaign) => {
          // Always use normalized ISO string!
          const campaignDateIso = toIsoDateString(campaign[key]);
          if (!campaignDateIso) return false;
          let valid = true;
          if (value.start)
            valid = valid && campaignDateIso >= toIsoDateString(value.start);
          if (value.end)
            valid = valid && campaignDateIso <= toIsoDateString(value.end);
          return valid;
        });
      } else {
        // text or number: substring match
        filtered = filtered.filter((campaign) => {
          const cellValue = campaign[key];
          if (cellValue == null) return false;
          return cellValue
            .toString()
            .toLowerCase()
            .includes(value.toString().toLowerCase());
        });
      }
    });

    setFilteredCampaigns(filtered);
    setCurrentPage(1);
  }, [searchTerm, columnFilters, startDate, endDate, campaigns]);
  useEffect(() => {
    if (!filteredCampaigns.length) return;
    const backendUrl =
      process.env.REACT_APP_BACKEND_URL || "http://localhost:5000";
    const itlCodes = filteredCampaigns.map((c) => c.ITL);

    // Build POST body, only add start/end if set
    const body = { itlCodes };
    if (startDate) body.start = startDate;
    if (endDate) body.end = endDate;

    axios
      .post(`${backendUrl}/api/leads/accepted-count-batch`, body)
      .then((res) => setAcceptedLeadCounts(res.data?.data || {}))
      .catch((err) => {
        console.error("Failed to fetch accepted counts", err);
        setAcceptedLeadCounts({});
      });
  }, [filteredCampaigns, startDate, endDate]);

  const normalizeCampaignData = (campaigns) => {
    return campaigns.map((c) => ({
      ...c,
      itl: c.ITL || c.itl || "",
      startDate: toIsoDateString(c["Start Date"] || c.startDate || ""),
      deadline: toIsoDateString(c.Deadline || c.deadline || ""),
      campaignAssignees: c["Campaign Assignees"] || c.campaignAssignees || "",
      dataCount: c["Data count"] || c.dataCount || 0,
      deliveryInsights: c["Delivery insights"] || c.deliveryInsights || "",
      emailInsights: c["Email insights"] || c.emailInsights || "",
      leadSent: c["Lead Sent"] != null ? c["Lead Sent"] : c.leadSent || 0,
      leadsBooked:
        c["Leads Booked"] != null ? c["Leads Booked"] : c.leadsBooked || 0,
      misCount: c["MIS Count"] || c.misCount || 0,
      opsCount: c["Ops Count"] || c.opsCount || 0,
      opsInsights: c["Ops Insights"] || c.opsInsights || "",
      qualityCount: c["Quality Count"] || c.qualityCount || 0,
      status: c.Status || c.status || "",
      campaignName: c.campaignName || "",
      cidNotes: c.cidNotes || "",
      dataComments: c.dataComments || "",
      date: c.date || "",
      deliveryDays: c.deliveryDays || "",
      pacing: c.pacing || "",
      sheetName: c.sheetName || "",
      shortfall: c.shortfall || 0,
      tactic: c.tactic || "",
    }));
  };

  // Fetch all data (no date filter)
  const fetchAllData = async () => {
    setLoading(true);
    setDeliveredCountLoading(true);
    try {
      const backendUrl =
        process.env.REACT_APP_BACKEND_URL || "http://localhost:5000";
      const token = localStorage.getItem("authToken");
      // Fetch all campaigns
      const campaignsRes = await fetch(`${backendUrl}/api/sheets/data`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const campaignsData = await campaignsRes.json();
      setCampaigns(campaignsData.data || []);
      setFilteredCampaigns(campaignsData.data || []);
      // Fetch all delivered count
      const deliveredRes = await fetch(
        `${backendUrl}/api/sheets/campaign-delivered-count`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      const deliveredData = await deliveredRes.json();
      setDeliveredCount(deliveredData.data?.totalDelivered || 0);
    } catch (err) {
      setDeliveredCount(null);
    } finally {
      setLoading(false);
      setDeliveredCountLoading(false);
    }
  };

  // Fetch filtered campaigns and delivered count when date range changes
  const fetchFilteredData = async (start, end) => {
    setLoading(true);
    setDeliveredCountLoading(true);
    try {
      const backendUrl =
        process.env.REACT_APP_BACKEND_URL || "http://localhost:5000";
      const token = localStorage.getItem("authToken");
      // Fetch campaigns in date range
      const campaignsRes = await fetch(
        `${backendUrl}/api/sheets/data?startDate=${start.toISOString()}&endDate=${end.toISOString()}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      const campaignsData = await campaignsRes.json();
      const normalized = normalizeCampaignData(campaignsData.data || []);

      setCampaigns(normalized);
      setFilteredCampaigns(normalized);
      // Fetch delivered count in date range
      const deliveredRes = await fetch(
        `${backendUrl}/api/sheets/campaign-delivered-count?startDate=${start.toISOString()}&endDate=${end.toISOString()}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      const deliveredData = await deliveredRes.json();
      setDeliveredCount(deliveredData.data?.totalDelivered || 0);
    } catch (err) {
      setDeliveredCount(null);
    } finally {
      setLoading(false);
      setDeliveredCountLoading(false);
    }
  };

  // Handler for filter bar 'Apply' button
  const handleApplyFilters = async () => {
    try {
      const backendUrl =
        process.env.REACT_APP_BACKEND_URL || "http://localhost:5000";
      setLoading(true);
      let url = `${backendUrl}/api/sheets/data`;
      const params = new URLSearchParams();

      if (startDate && endDate) {
        params.append("startDate", startDate);
        params.append("endDate", endDate);
      }

      if (searchTerm) {
        params.append("search", searchTerm);
      }

      Object.entries(columnFilters).forEach(([key, value]) => {
        if (value) {
          if (typeof value === "object" && value.start && value.end) {
            params.append(`${key}Start`, value.start);
            params.append(`${key}End`, value.end);
          } else {
            params.append(key, value);
          }
        }
      });

      const queryString = params.toString();
      if (queryString) {
        url += `?${queryString}`;
      }

      const response = await axios.get(url);

      if (response.data && response.data.data) {
        const normalized = normalizeCampaignData(response.data.data || []);
        setCampaigns(normalized);
        setFilteredCampaigns(normalized);
      }
    } catch (error) {
      console.error("Error applying filters:", error);
      setError("Failed to apply filters. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // Helper function to convert month abbreviation to index
  const getMonthIndex = (month) => {
    const months = {
      Jan: 0,
      Feb: 1,
      Mar: 2,
      Apr: 3,
      May: 4,
      Jun: 5,
      Jul: 6,
      Aug: 7,
      Sep: 8,
      Oct: 9,
      Nov: 10,
      Dec: 11,
    };
    return months[month];
  };

  // Handler for clearing all filters
  const handleClearFilters = () => {
    setStartDate(null);
    setEndDate(null);
    setSearchTerm("");
    fetchAllData();
  };
  // Normalization (guarantee this is called for every record before filtering!)
  function toIsoDateString(raw) {
    if (!raw) return "";
    if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;
    // Parse DD-MMM-YY
    const match = raw.match(/^(\d{1,2})-(\w{3})-(\d{2,4})$/);
    if (match) {
      let [_, day, month, year] = match;
      if (year.length === 2) year = "20" + year;
      const d = new Date(`${day} ${month} ${year}`);
      if (!isNaN(d)) return d.toISOString().slice(0, 10);
    }
    // Fallback: try Date.parse
    const d = new Date(raw);
    if (!isNaN(d)) return d.toISOString().slice(0, 10);
    return "";
  }

  // Search and filter logic
  useEffect(() => {
    let filtered = [...campaigns];
    if (searchTerm && searchTerm.trim() !== "") {
      const searchLower = searchTerm.trim().toLowerCase();
      filtered = filtered.filter((campaign) => {
        // Search only in ITL code
        const itl = (campaign.ITL ?? "").toString().trim().toLowerCase();
        return itl.includes(searchLower);
      });
    }
    setFilteredCampaigns(filtered);
  }, [searchTerm, campaigns]);

  // On mount, load all data
  useEffect(() => {
    fetchAllData();
  }, []);

  // Add click-outside functionality for filter dropdowns
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!event.target.closest(".filter-wrapper")) {
        setShowFilters({});
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const backendUrl =
        process.env.REACT_APP_BACKEND_URL || "http://localhost:5000";
      console.log("🔍 Fetching data from:", `${backendUrl}/api/sheets/data`);

      const response = await fetch(`${backendUrl}/api/sheets/data`);

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      console.log(
        "📊 Fetched campaigns data:",
        (data.data || []).length,
        "campaigns"
      );

      // Filter out entries without ITL code
      const validCampaigns = (data.data || []).filter(
        (campaign) => campaign.ITL && campaign.ITL.toString().trim() !== ""
      );

      console.log(
        "📊 Valid campaigns with ITL:",
        validCampaigns.length,
        "campaigns"
      );
      const normalized = normalizeCampaignData(validCampaigns || []);

      setCampaigns(normalized);
      setFilteredCampaigns(normalized);
    } catch (error) {
      console.error("❌ Error fetching data:", error);
      // Try to show a user-friendly error
      alert(`Failed to fetch campaign data: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleColumnFilter = (columnKey, value) => {
    console.log(`🔧 Setting filter for ${columnKey}:`, value);
    setColumnFilters((prev) => ({
      ...prev,
      [columnKey]: value,
    }));
    setShowFilters((prev) => ({
      ...prev,
      [columnKey]: false,
    }));
  };

  const clearColumnFilter = (columnKey) => {
    setColumnFilters((prev) => {
      const newFilters = { ...prev };
      delete newFilters[columnKey];
      return newFilters;
    });
  };

  const clearAllFilters = () => {
    setColumnFilters({});
    setSearchTerm("");
    setShowFilters({});
  };

  const exportToExcel = () => {
    // Prepare data for export
    const dataToExport = filteredCampaigns.map((campaign) => {
      const exportRow = {};
      COLUMNS.forEach((column) => {
        exportRow[column.label] = campaign[column.key] || "";
      });
      return exportRow;
    });

    // Convert to CSV format
    const headers = COLUMNS.map((col) => col.label).join(",");
    const csvData = dataToExport
      .map((row) =>
        COLUMNS.map((col) => {
          const value = row[col.label] || "";
          // Escape commas and quotes in values
          return `"${value.toString().replace(/"/g, '""')}"`;
        }).join(",")
      )
      .join("\n");

    const csvContent = headers + "\n" + csvData;

    // Create and download file
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute(
      "download",
      `campaigns_filtered_${new Date().toISOString().split("T")[0]}.csv`
    );
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Helper function to get available filter values for a specific column
  // considering current search and other active filters (Excel-like behavior)
  const getAvailableFilterValues = (targetColumnKey) => {
    if (campaigns.length === 0) return [];

    let filtered = [...campaigns];

    // Apply search filter first (ITL only)
    if (searchTerm && searchTerm.trim() !== "") {
      const searchLower = searchTerm.toLowerCase().trim();
      filtered = filtered.filter(
        (campaign) =>
          campaign.ITL &&
          campaign.ITL.toString().toLowerCase().includes(searchLower)
      );
    }

    // Apply all column filters EXCEPT the target column
    Object.entries(columnFilters).forEach(([columnKey, filterValue]) => {
      if (!filterValue || columnKey === targetColumnKey) return;

      const column = COLUMNS.find((col) => col.key === columnKey);

      if (column?.type === "date") {
        if (
          typeof filterValue === "object" &&
          (filterValue.start || filterValue.end)
        ) {
          filtered = filtered.filter((campaign) => {
            const campaignDate = new Date(campaign[columnKey]);
            if (isNaN(campaignDate)) return false;

            let matchesStart = true;
            let matchesEnd = true;

            if (filterValue.start) {
              const startDate = new Date(filterValue.start);
              matchesStart = campaignDate >= startDate;
            }

            if (filterValue.end) {
              const endDate = new Date(filterValue.end);
              matchesEnd = campaignDate <= endDate;
            }

            return matchesStart && matchesEnd;
          });
        }
      } else {
        if (typeof filterValue === "string" && filterValue.trim() !== "") {
          const filterLower = filterValue.toLowerCase().trim();
          filtered = filtered.filter((campaign) => {
            const value = campaign[columnKey];
            return (
              value && value.toString().toLowerCase().includes(filterLower)
            );
          });
        }
      }
    });

    // Extract unique values for the target column from filtered data
    const values = filtered
      .map((campaign) => campaign[targetColumnKey])
      .filter((value) => value && value.toString().trim() !== "")
      .map((value) => value.toString().trim());

    return [...new Set(values)].sort();
  };

  const toggleFilterDropdown = (columnKey) => {
    setShowFilters((prev) => ({
      ...prev,
      [columnKey]: !prev[columnKey],
    }));
    if (!showFilters[columnKey]) {
      setDateFilterDrafts((prev) => ({
        ...prev,
        [columnKey]: columnFilters[columnKey] || { start: "", end: "" },
      }));
    }
  };

  const totalPages = Math.ceil(filteredCampaigns.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const currentCampaigns = filteredCampaigns.slice(
    startIndex,
    startIndex + itemsPerPage
  );

  // Debug pagination
  React.useEffect(() => {
    console.log("Pagination Debug:", {
      totalCampaigns: filteredCampaigns.length,
      itemsPerPage,
      currentPage,
      totalPages,
      startIndex,
      currentCampaignsLength: currentCampaigns.length,
    });
  }, [
    filteredCampaigns.length,
    itemsPerPage,
    currentPage,
    totalPages,
    startIndex,
    currentCampaigns.length,
  ]);

  const getCampaignStats = () => {
    // Use filtered campaigns for stats calculation
    const total = filteredCampaigns.length;
    const live = filteredCampaigns.filter((c) => c.Status === "Live").length;
    const completed = filteredCampaigns.filter((c) =>
      c.Status?.includes("Completed")
    ).length;
    const paused = filteredCampaigns.filter(
      (c) => c.Status === "Paused"
    ).length;

    // Calculate leads sent/delivered from filtered campaigns
    const totalLeadsSent = filteredCampaigns.reduce(
      (sum, c) => sum + (parseInt(c["Lead Sent"]) || 0),
      0
    );
    const totalLeadsDelivered = filteredCampaigns.reduce(
      (sum, c) => sum + (parseInt(c["Leads Booked"]) || 0),
      0
    );

    return {
      total,
      live,
      completed,
      paused,
      leadsSent: totalLeadsSent,
      leadsDelivered: totalLeadsDelivered,
    };
  };

  const stats = getCampaignStats();

  // Show loading spinner for initial data load
  if (loading && campaigns.length === 0) {
    return (
      <div className="dashboard-container">
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            height: "50vh",
            gap: "1rem",
          }}
        >
          <FaSpinner
            className="spinner"
            style={{ fontSize: "2rem", color: "#0ea5e9" }}
          />
          <p style={{ color: "#6b7280", fontSize: "1.1rem" }}>
            Loading campaign data...
          </p>
        </div>
      </div>
    );
  }

  // Simple pie chart component for fallback
  const SimplePieChart = () => (
    <div
      style={{
        width: "200px",
        height: "200px",
        borderRadius: "50%",
        background: `conic-gradient(
        #10b981 0deg ${(stats.live / stats.total) * 360}deg,
        #0ea5e9 ${(stats.live / stats.total) * 360}deg ${
          ((stats.live + stats.completed) / stats.total) * 360
        }deg,
        #f59e0b ${((stats.live + stats.completed) / stats.total) * 360}deg ${
          ((stats.live + stats.completed + stats.paused) / stats.total) * 360
        }deg,
        #ef4444 ${
          ((stats.live + stats.completed + stats.paused) / stats.total) * 360
        }deg 360deg
      )`,
        margin: "auto",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flexShrink: 0, // Prevent shrinking
      }}
    >
      <div
        style={{
          width: "120px",
          height: "120px",
          backgroundColor: "white",
          borderRadius: "50%",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          fontSize: "0.875rem",
          fontWeight: "600",
          color: "#374151",
        }}
      >
        <div style={{ fontSize: "1.5rem", fontWeight: "700" }}>
          {stats.total}
        </div>
        <div>Total</div>
      </div>
    </div>
  );

  return (
    <div className="dashboard-container">
      <div className="filter-bar">
        <div className="dashboard-stats">
          {/* {deliveredCountLoading ? (
            <div className="stat-loading">Loading delivered count...</div>
          ) : (
            <div className="stat-item" style={{display: "none"}}>
              <span className="stat-label">Leads Delivered:</span>
              <span className="stat-value">
                {deliveredCount !== null ? deliveredCount : "-"}
              </span>
            </div>
          )} */}
        </div>
        <div className="hero-stats">
          <div className="stat-card">
            <span className="stat-number">{stats.total}</span>
            <span className="stat-label">Total</span>
          </div>
          <div className="stat-card live">
            <span className="stat-number">{stats.live}</span>
            <span className="stat-label">Live</span>
          </div>
          <div className="stat-card completed">
            <span className="stat-number">{stats.completed}</span>
            <span className="stat-label">Completed</span>
          </div>
          <div className="stat-card paused">
            <span className="stat-number">{stats.paused}</span>
            <span className="stat-label">Paused</span>
          </div>

          <div className="stat-card leads-delivered">
            <span className="stat-number">
              {stats.leadsSent.toLocaleString()}
            </span>
            <span className="stat-label">Leads Delivered</span>
          </div>
        </div>
      </div>

      {/* Compact Hero Section */}
      <div className="hero-section">
        <div className="hero-content">
          <div className="hero-text">
            <h1>Campaign Dashboard</h1>
            <p>Real-time campaign management and analytics</p>
          </div>
        </div>
      </div>

      {/* Compact Controls */}

      {/* Main Content Grid */}
      <div className="main-content">
        {/* Chart Section */}
        <div className="chart-section">
          <div className="chart-card">
            <div className="card-header">
              <FaChartPie />
              <span>Status Distribution</span>
            </div>

            <div className="chart-container">
              <Suspense
                fallback={
                  <div className="chart-loading">
                    <FaSpinner className="spinner" />
                    <span>Loading chart...</span>
                  </div>
                }
              >
                {stats.total > 0 ? (
                  <StatusDistributionCharts
                    key={`pie-chart-${stats.total}-${stats.live}-${stats.completed}-${stats.paused}`}
                    filteredCampaigns={filteredCampaigns}
                  />
                ) : (
                  <SimplePieChart />
                )}
              </Suspense>
            </div>
          </div>
        </div>

        {/* Table Section */}
        <div className="table-section">
          <div className="table-card">
            <div className="card-header">
              <div
                style={{ display: "flex", alignItems: "center", gap: "8px" }}
              >
                <FaTable />
                <span>Campaigns ({filteredCampaigns.length})</span>
              </div>
              <div className="filter-controls">
                {/* <CalendarRangePicker
            startDate={startDate}
            endDate={endDate}
            setStartDate={setStartDate}
            setEndDate={setEndDate}
            onFilter={handleApplyFilters}
          /> */}
                <div className="search-container">
                  <input
                    type="text"
                    className="filter-search-input"
                    placeholder="Search by ITL code..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />

                  <button
                    className="calendar-search-btn"
                    onClick={() => {}}
                    title="Apply filters"
                  >
                    <FaSearch className="search-icon" />
                    <span className="refresh-btn" style={{ color: "white" }}>
                      Search
                    </span>
                  </button>
                </div>
              </div>
              <div
                style={{ display: "flex", alignItems: "center", gap: "10px" }}
              >
                <CalendarRangePicker
                  startDate={startDate}
                  endDate={endDate}
                  setStartDate={setStartDate}
                  setEndDate={setEndDate}
                  onFilter={handleApplyFilters}
                />
                <button
                  className="filter-clear-btn"
                  onClick={handleClearFilters}
                >
                  Clear
                </button>
              </div>

              <div className="controls-right">
                <div className="connection-status">
                  {connected ? (
                    <>
                      <FaWifi className="status-icon connected" />
                      <span>Connected</span>
                    </>
                  ) : (
                    <>
                      <FaExclamationTriangle className="status-icon disconnected" />
                      <span>Disconnected</span>
                    </>
                  )}
                </div>

                <button
                  onClick={fetchData}
                  disabled={loading}
                  className="refresh-btn"
                >
                  <FaSync className={loading ? "spinning" : ""} />
                  {loading ? "Loading..." : "Refresh"}
                </button>

                <button
                  onClick={exportToExcel}
                  className="export-btn"
                  title="Export filtered data to Excel"
                >
                  <FaDownload />
                  Export
                </button>
              </div>
            </div>

            <div className="table-container">
              <table className="campaigns-table">
                <thead>
                  <tr>
                    {COLUMNS.map((column) => (
                      <th
                        key={column.key}
                        className="filterable-header center-header"
                      >
                        <div className="header-content">
                          <span className="header-label">{column.label}</span>
                          <div className="filter-wrapper">
                            <button
                              className="filter-btn"
                              onClick={() => toggleFilterDropdown(column.key)}
                              title={`Filter by ${column.label}`}
                            >
                              {column.type === "date" ? (
                                <FaCalendarAlt />
                              ) : (
                                <FaFilter />
                              )}
                              {columnFilters[column.key] && (
                                <span className="filter-active-dot"></span>
                              )}
                            </button>

                            {showFilters[column.key] && (
                              <div className="filter-dropdown">
                                {column.type === "date" ? (
                                  <div className="date-filter-content">
                                    <div className="date-input-group">
                                      <label>From:</label>
                                      <input
                                        type="date"
                                        value={
                                          dateFilterDrafts[column.key]?.start ??
                                          columnFilters[column.key]?.start ??
                                          ""
                                        }
                                        onChange={(e) =>
                                          setDateFilterDrafts((prev) => ({
                                            ...prev,
                                            [column.key]: {
                                              ...prev[column.key],
                                              start: e.target.value,
                                            },
                                          }))
                                        }
                                      />
                                    </div>
                                    <div className="date-input-group">
                                      <label>To:</label>
                                      <input
                                        type="date"
                                        value={
                                          dateFilterDrafts[column.key]?.end ??
                                          columnFilters[column.key]?.end ??
                                          ""
                                        }
                                        onChange={(e) =>
                                          setDateFilterDrafts((prev) => ({
                                            ...prev,
                                            [column.key]: {
                                              ...prev[column.key],
                                              end: e.target.value,
                                            },
                                          }))
                                        }
                                      />
                                    </div>
                                    <div className="filter-actions">
                                      <button
                                        className="clear-filter-btn"
                                        onClick={() => {
                                          handleColumnFilter(
                                            column.key,
                                            dateFilterDrafts[column.key]
                                          );
                                          setShowFilters((prev) => ({
                                            ...prev,
                                            [column.key]: false,
                                          }));
                                          setDateFilterDrafts((prev) => ({
                                            ...prev,
                                            [column.key]: undefined,
                                          }));
                                        }}
                                        disabled={
                                          !dateFilterDrafts[column.key]
                                            ?.start &&
                                          !dateFilterDrafts[column.key]?.end
                                        }
                                      >
                                        Apply
                                      </button>
                                      <button
                                        className="clear-filter-btn"
                                        onClick={() => {
                                          clearColumnFilter(column.key);
                                          setDateFilterDrafts((prev) => ({
                                            ...prev,
                                            [column.key]: undefined,
                                          }));
                                          setShowFilters((prev) => ({
                                            ...prev,
                                            [column.key]: false,
                                          }));
                                        }}
                                      >
                                        Clear
                                      </button>
                                    </div>
                                  </div>
                                ) : (
                                  <div className="dropdown-filter-content">
                                    <input
                                      type="text"
                                      placeholder={`Search ${column.label}...`}
                                      value={columnFilters[column.key] || ""}
                                      onChange={(e) =>
                                        handleColumnFilter(
                                          column.key,
                                          e.target.value
                                        )
                                      }
                                      className="filter-search-input"
                                    />
                                    <div className="filter-options">
                                      {getAvailableFilterValues(column.key)
                                        .slice(0, 10)
                                        .map((value) => (
                                          <div
                                            key={value}
                                            className="filter-option"
                                            onClick={() =>
                                              handleColumnFilter(
                                                column.key,
                                                value
                                              )
                                            }
                                          >
                                            {value}
                                          </div>
                                        ))}
                                    </div>
                                    <div className="filter-actions">
                                      <button
                                        className="clear-filter-btn"
                                        onClick={() =>
                                          clearColumnFilter(column.key)
                                        }
                                      >
                                        Clear
                                      </button>
                                    </div>
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {currentCampaigns.map((campaign, index) => (
                    <tr key={campaign.ITL || index} className="campaign-row">
                      {COLUMNS.map((column) => (
                        <td key={column.key} className={column.className || ""}>
                          {column.key === "ITL" ? (
                            <button
                              onClick={() => onCampaignSelect(campaign)}
                              className="itl-link"
                              title="View Campaign Details"
                            >
                              {campaign[column.key] || "N/A"}
                            </button>
                          ) : column.key === "Lead Sent" ||
                            column.key === "leadSent" ? (
                            // Show accepted leads count for this ITL
                            acceptedLeadCounts &&
                            acceptedLeadCounts[campaign.ITL] !== undefined ? (
                              acceptedLeadCounts[campaign.ITL]
                            ) : (
                              <FaSpinner className="spinner" />
                            )
                          ) : (
                            campaign[column.key] || "N/A"
                          )}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Enhanced Pagination - Always visible */}
            <div
              className="pagination"
              style={{
                display: "flex",
                backgroundColor: "#f3f4f6",
                borderTop: "1px solid #e5e7eb",
                minHeight: "60px",
              }}
            >
              <button
                onClick={() => setCurrentPage(1)}
                disabled={currentPage === 1 || totalPages <= 1}
                className="page-btn"
                title="First page"
              >
                ««
              </button>
              <button
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1 || totalPages <= 1}
                className="page-btn"
                title="Previous page"
              >
                ←
              </button>

              <div className="page-info">
                <span className="page-current">
                  {totalPages > 1
                    ? `Page ${currentPage} of ${totalPages}`
                    : "All Results"}
                </span>
                <span className="page-details">
                  Showing {startIndex + 1}-
                  {Math.min(
                    startIndex + itemsPerPage,
                    filteredCampaigns.length
                  )}{" "}
                  of {filteredCampaigns.length} campaigns
                </span>
              </div>

              <button
                onClick={() =>
                  setCurrentPage(Math.min(totalPages, currentPage + 1))
                }
                disabled={currentPage === totalPages || totalPages <= 1}
                className="page-btn"
                title="Next page"
              >
                →
              </button>
              <button
                onClick={() => setCurrentPage(totalPages)}
                disabled={currentPage === totalPages || totalPages <= 1}
                className="page-btn"
                title="Last page"
              >
                »»
              </button>
              <div className="controls-left">
                <div className="search-box">
                  <FaSearch className="search-icon" />
                  <input
                    type="text"
                    placeholder="Search campaigns..."
                    value={searchTerm}
                    onChange={(e) => {
                      console.log("🔍 Search input changed:", e.target.value);
                      setSearchTerm(e.target.value);
                    }}
                    className="search-input"
                  />
                </div>

                <select
                  value={itemsPerPage}
                  onChange={(e) => {
                    setItemsPerPage(Number(e.target.value));
                    setCurrentPage(1); // Reset to first page when changing page size
                  }}
                  className="filter-select"
                  title="Items per page"
                >
                  <option value={5}>5 per page</option>
                  <option value={10}>10 per page</option>
                  <option value={20}>20 per page</option>
                  <option value={50}>50 per page</option>
                </select>

                {Object.keys(columnFilters).length > 0 && (
                  <button
                    onClick={clearAllFilters}
                    className="clear-filters-btn"
                    title="Clear all filters"
                  >
                    Clear Filters ({Object.keys(columnFilters).length})
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardTable;

const styles = `
  .search-btn {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 16px;
    background: linear-gradient(135deg, #4a90e2 0%, #357abd 100%);
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s ease;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }

  .search-btn:hover {
    background: linear-gradient(135deg, #357abd 0%, #2a5f9e 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
  }

  .search-btn:active {
    transform: translateY(0);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }

  .search-icon {
    font-size: 16px;
  }

  .filter-btn {
    background: #f5f5f5;
    border: 1px solid #e0e0e0;
    border-radius: 4px;
    padding: 6px;
    cursor: pointer;
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .filter-btn:hover {
    background: #e8e8e8;
    border-color: #d0d0d0;
  }

  .filter-btn svg {
    color: #666;
    font-size: 14px;
  }

  .filter-active-dot {
    position: absolute;
    top: -2px;
    right: -2px;
    width: 8px;
    height: 8px;
    background: #4a90e2;
    border-radius: 50%;
    border: 2px solid white;
  }

  .calendar-search-btn {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 16px;
    background: linear-gradient(135deg, #4a90e2 0%, #357abd 100%);
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s ease;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    margin: 0 8px;
  }

  .calendar-search-btn:hover {
    background: linear-gradient(135deg, #357abd 0%, #2a5f9e 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
  }

  .calendar-search-btn:active {
    transform: translateY(0);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }

  .calendar-search-btn .search-icon {
    font-size: 16px;
  }

  .filter-controls {
    display: flex;
    align-items: center;
    gap: 16px;
  }

  .search-container {
    display: flex;
    align-items: center;
  
  }

  .filter-search-input {
    padding: 8px 12px;
    border: 1px solid #e0e0e0;
    border-radius: 6px;
    font-size: 14px;
    width: 200px;
    transition: all 0.2s ease;
  }

  .filter-search-input:focus {
    border-color: #4a90e2;
    box-shadow: 0 0 0 2px rgba(74, 144, 226, 0.1);
    outline: none;
  }
`;
