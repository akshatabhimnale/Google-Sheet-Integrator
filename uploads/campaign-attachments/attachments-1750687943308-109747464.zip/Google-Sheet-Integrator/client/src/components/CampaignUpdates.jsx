import React, { useState, useEffect, useRef } from 'react';
import { 
  FaComments, 
  FaPaperPlane, 
  FaUser, 
  FaClock, 
  FaSpinner,
  FaExclamationCircle 
} from 'react-icons/fa';
import io from 'socket.io-client';
import './CampaignUpdates.css';

const CampaignUpdates = ({ campaignId, campaignName }) => {
  const [updates, setUpdates] = useState([]);
  const [newUpdate, setNewUpdate] = useState('');
  const [loading, setLoading] = useState(true);
  const [posting, setPosting] = useState(false);
  const [error, setError] = useState(null);
  const [socket, setSocket] = useState(null);
  const [currentUser] = useState({
    id: 'user_' + Math.random().toString(36).substr(2, 9),
    name: 'Current User' // You can replace this with actual user authentication
  });
  
  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);

  // Auto-scroll to bottom when new messages arrive
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // Fetch existing updates
  const fetchUpdates = async () => {
    try {
      setLoading(true);
      const response = await fetch(
        `${process.env.REACT_APP_BACKEND_URL || 'http://localhost:5000'}/api/sheets/campaigns/${encodeURIComponent(campaignId)}/updates`
      );
      
      if (!response.ok) {
        throw new Error('Failed to fetch updates');
      }
      
      const data = await response.json();
      setUpdates(data);
      setError(null);
    } catch (err) {
      console.error('Error fetching updates:', err);
      setError('Failed to load updates');
    } finally {
      setLoading(false);
    }
  };

  // Add new update
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!newUpdate.trim()) return;
    
    try {
      setPosting(true);
      const response = await fetch(
        `${process.env.REACT_APP_BACKEND_URL || 'http://localhost:5000'}/api/sheets/campaigns/${encodeURIComponent(campaignId)}/updates`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            message: newUpdate,
            userId: currentUser.id,
            userName: currentUser.name,
          }),
        }
      );
      
      if (!response.ok) {
        throw new Error('Failed to post update');
      }
      
      const result = await response.json();
      
      // Add the new update to the list (it will also come via WebSocket)
      setUpdates(prev => [result.update, ...prev]);
      setNewUpdate('');
      setError(null);
      
      // Auto-resize textarea
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
      
    } catch (err) {
      console.error('Error posting update:', err);
      setError('Failed to post update');
    } finally {
      setPosting(false);
    }
  };

  // Handle textarea auto-resize
  const handleTextareaChange = (e) => {
    setNewUpdate(e.target.value);
    
    // Auto-resize
    const textarea = e.target;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
  };

  // Format timestamp
  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    
    // Less than 1 minute
    if (diff < 60000) {
      return 'Just now';
    }
    
    // Less than 1 hour
    if (diff < 3600000) {
      const minutes = Math.floor(diff / 60000);
      return `${minutes}m ago`;
    }
    
    // Less than 24 hours
    if (diff < 86400000) {
      const hours = Math.floor(diff / 3600000);
      return `${hours}h ago`;
    }
    
    // More than 24 hours - show date
    if (date.toDateString() === now.toDateString()) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else {
      return date.toLocaleDateString([], { 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit', 
        minute: '2-digit' 
      });
    }
  };

  // Initialize socket connection and fetch data
  useEffect(() => {
    fetchUpdates();
    
    // Initialize WebSocket for real-time updates
    const socketInstance = io(process.env.REACT_APP_BACKEND_URL || 'http://localhost:5000');
    setSocket(socketInstance);
    
    // Listen for new campaign updates
    socketInstance.on('campaignUpdateAdded', (data) => {
      if (data.campaignId === campaignId) {
        setUpdates(prev => {
          // Avoid duplicates
          const exists = prev.some(update => update._id === data.update._id);
          if (!exists) {
            return [data.update, ...prev];
          }
          return prev;
        });
      }
    });

    return () => {
      socketInstance.disconnect();
    };
  }, [campaignId]);

  // Scroll to bottom when updates change
  useEffect(() => {
    scrollToBottom();
  }, [updates]);

  return (
    <div className="campaign-updates">
      <div className="updates-header">
        <div className="updates-title">
          <FaComments className="updates-icon" />
          <h3>Campaign Updates</h3>
        </div>
        <div className="updates-count">
          {updates.length} update{updates.length !== 1 ? 's' : ''}
        </div>
      </div>

      {error && (
        <div className="updates-error">
          <FaExclamationCircle />
          <span>{error}</span>
        </div>
      )}

      <div className="updates-content">
        <form onSubmit={handleSubmit} className="update-form">
          <div className="form-group">
            <div className="user-avatar">
              <FaUser />
            </div>
            <div className="input-group">
              <textarea
                ref={textareaRef}
                value={newUpdate}
                onChange={handleTextareaChange}
                placeholder={`Add an update for ${campaignName}...`}
                className="update-input"
                disabled={posting}
                rows="1"
              />
              <button 
                type="submit" 
                className="send-button"
                disabled={!newUpdate.trim() || posting}
              >
                {posting ? <FaSpinner className="spinning" /> : <FaPaperPlane />}
              </button>
            </div>
          </div>
        </form>

        <div className="updates-list">
          {loading ? (
            <div className="loading-state">
              <FaSpinner className="spinning" />
              <span>Loading updates...</span>
            </div>
          ) : updates.length === 0 ? (
            <div className="empty-state">
              <FaComments className="empty-icon" />
              <p>No updates yet</p>
              <span>Be the first to add an update for this campaign!</span>
            </div>
          ) : (
            updates.map((update) => (
              <div key={update._id} className="update-item">
                <div className="update-avatar">
                  <FaUser />
                </div>
                <div className="update-content">
                  <div className="update-header">
                    <span className="update-author">{update.userName}</span>
                    <div className="update-time">
                      <FaClock className="time-icon" />
                      <span>{formatTimestamp(update.timestamp)}</span>
                    </div>
                  </div>
                  <div className="update-message">
                    {update.message}
                  </div>
                </div>
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>
    </div>
  );
};

export default CampaignUpdates; 