import React from "react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";

const StatusDistributionCharts = ({ filteredCampaigns = [] }) => {
  // Calculate stats from filtered campaigns
  const total = filteredCampaigns.length;
  const live = filteredCampaigns.filter((c) => c.Status === "Live").length;
  const completed = filteredCampaigns.filter((c) =>
    c.Status?.includes("Completed")
  ).length;
  const paused = filteredCampaigns.filter((c) => c.Status === "Paused").length;

  // Data for each pie chart - showing each status OUT OF TOTAL
  const liveData = [
    { name: "Live", value: live, color: "#10b981" },
    { name: "Others", value: total - live, color: "#f3f4f6" },
  ];

  const completedData = [
    { name: "Completed", value: completed, color: "#0ea5e9" },
    { name: "Others", value: total - completed, color: "#f3f4f6" },
  ];

  const pausedData = [
    { name: "Paused", value: paused, color: "#f59e0b" },
    { name: "Others", value: total - paused, color: "#f3f4f6" },
  ];

  // Total distribution chart showing all statuses
  const totalData = [
    { name: "Live", value: live, color: "#10b981" },
    { name: "Completed", value: completed, color: "#0ea5e9" },
    { name: "Paused", value: paused, color: "#f59e0b" },
    {
      name: "Others",
      value: total - live - completed - paused,
      color: "#6b7280",
    },
  ].filter((item) => item.value > 0); // Only show non-zero values

  const CustomTooltip = ({ active, payload, data, chartType }) => {
    if (active && payload && payload.length) {
      const currentData = payload[0].payload;
      if (currentData.name === "Others" && chartType !== "Total Distribution")
        return null;

      return (
        <div
          style={{
            backgroundColor: "rgba(0, 0, 0, 0.85)",
            color: "white",
            padding: "8px 12px",
            borderRadius: "6px",
            fontSize: "0.8rem",
            boxShadow: "0 8px 20px -5px rgba(0, 0, 0, 0.25)",
            backdropFilter: "blur(10px)",
            border: "1px solid rgba(255, 255, 255, 0.1)",
          }}
        >
          <p
            style={{
              margin: "0 0 4px 0",
              fontWeight: "600",
              color: currentData.color,
            }}
          >
            {currentData.name}
          </p>
          <p style={{ margin: 0, opacity: 0.9, fontSize: "0.75rem" }}>
            <strong>{currentData.value}</strong> out of {total} campaigns
          </p>
          <p style={{ margin: "2px 0 0 0", opacity: 0.8, fontSize: "0.7rem" }}>
            {total > 0
              ? `${((currentData.value / total) * 100).toFixed(1)}%`
              : "0%"}{" "}
            of total
          </p>
        </div>
      );
    }
    return null;
  };

  const renderPieChart = (
    data,
    title,
    centerValue,
    centerLabel,
    showOutOfTotal = true
  ) => (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        flex: 1,
        padding: "6px",
        minWidth: "0",
      }}
    >
      <h5
        style={{
          margin: "0 0 8px 0",
          fontSize: "0.75rem",
          fontWeight: "600",
          color: "#374151",
          textAlign: "center",
          letterSpacing: "0.02em",
        }}
      >
        {title}
      </h5>
      <div style={{ position: "relative", width: "90px", height: "90px" }}>
        {/* <ResponsiveContainer width="100%" height="100%"> */}
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={28}
            outerRadius={38}
            startAngle={90}
            endAngle={450}
            paddingAngle={1}
            dataKey="value"
            strokeWidth={0}
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
            ))}
          </Pie>
          <Tooltip
            content={(props) => <CustomTooltip {...props} chartType={title} />}
          />
        </PieChart>
        {/* </ResponsiveContainer> */}

        {/* Compact center label */}
        <div
          style={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            textAlign: "center",
            pointerEvents: "none",
          }}
        >
          <div
            style={{
              fontSize: "1.2rem",
              fontWeight: "700",
              color: data[0]?.color || "#374151",
              lineHeight: "1.1",
            }}
          >
            {centerValue}
          </div>
          <div
            style={{
              fontSize: "0.6rem",
              color: "#6b7280",
              lineHeight: "1",
              fontWeight: "500",
              textTransform: "uppercase",
              letterSpacing: "0.05em",
            }}
          >
            {centerLabel}
          </div>
        </div>
      </div>

      {/* Enhanced percentage display with "out of total" */}
      <div
        style={{
          fontSize: "0.7rem",
          color: "#4b5563",
          marginTop: "4px",
          textAlign: "center",
          fontWeight: "500",
          background: "rgba(248, 250, 252, 0.8)",
          padding: "2px 8px",
          borderRadius: "12px",
          border: "1px solid #e2e8f0",
        }}
      >
        {showOutOfTotal ? (
          <>
            <div>
              {centerValue} / {total}
            </div>
            {/* <div style={{ fontSize: '0.65rem', opacity: 0.8 }}>
              {total > 0 ? `${((centerValue / total) * 100).toFixed(0)}%` : '0%'}
            </div> */}
          </>
        ) : (
          `${total > 0 ? `${((centerValue / total) * 100).toFixed(0)}%` : "0%"}`
        )}
      </div>
    </div>
  );

  if (total === 0) {
    return (
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          height: "200px",
          color: "#6b7280",
          fontSize: "0.875rem",
          background: "linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%)",
          borderRadius: "8px",
          border: "1px solid #e2e8f0",
        }}
      >
        <div style={{ fontSize: "2.5rem", marginBottom: "8px", opacity: 0.6 }}>
          📊
        </div>
        <div style={{ fontWeight: "500" }}>No campaign data</div>
        <div style={{ fontSize: "0.75rem", opacity: 0.7, marginTop: "4px" }}>
          Apply filters to see results
        </div>
      </div>
    );
  }

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: "8px",
        padding: "12px 8px 8px 8px",
        height: "100%",
        background: "linear-gradient(135deg, #fefefe 0%, #f8fafc 100%)",
        borderRadius: "8px",
      }}
    >
      {/* Top row */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          gap: "8px",
        }}
      >
        {renderPieChart(liveData, "Live", live, true)}
        {renderPieChart(completedData, "Completed", completed, true)}
      </div>

      {/* Bottom row */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          gap: "8px",
        }}
      >
        {renderPieChart(pausedData, "Paused", paused, true)}
      </div>
    </div>
  );
};

export default StatusDistributionCharts;
