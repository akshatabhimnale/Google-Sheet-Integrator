import React, { useState,useEffect, useRef } from 'react';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import { FaRegCalendarAlt } from 'react-icons/fa';
import './CalendarRangePicker.css';

const CalendarRangePicker = ({ startDate, endDate, setStartDate, setEndDate, onFilter }) => {
  const [showPicker, setShowPicker] = useState(false);

  const handleStartChange = (date) => {
    setStartDate(date);
  };

  const handleEndChange = (date) => {
    setEndDate(date);
  };

  const pickerRef = useRef(null);

useEffect(() => {
  const handleClickOutside = (event) => {
    if (pickerRef.current && !pickerRef.current.contains(event.target)) {
      setShowPicker(false);
    }
  };

  if (showPicker) {
    document.addEventListener("mousedown", handleClickOutside);
  } else {
    document.removeEventListener("mousedown", handleClickOutside);
  }

  return () => {
    document.removeEventListener("mousedown", handleClickOutside);
  };
}, [showPicker]);

  return (
    <div className="calendar-wrapper" ref={pickerRef}>

      <div className="calendar-input-container">
        <input
          type="text"
          className="date-display"
          value={
            startDate && endDate 
              ? `${startDate.toLocaleDateString()} : ${endDate.toLocaleDateString()}`
              : ''
          }
          readOnly
          onClick={() => setShowPicker(!showPicker)}
        />
        <FaRegCalendarAlt 
          className="calendar-icon" 
          onClick={() => setShowPicker(!showPicker)} 
        />
      </div>

      {showPicker && (
        <div className="calendar-popup">
          <div className="calendar-container">
            <div className="calendar-row">
              {/* Start Calendar */}
              <div className="calendar-picker">
                <label className="calendar-label">Start Date</label>
                <Calendar
                  onChange={handleStartChange}
                  value={startDate}
                  minDetail="year"
                  maxDetail="month"
                  prevLabel={null}
                  nextLabel={null}
                  navigationLabel={({ date }) => `${date.toLocaleString('default', { month: 'long' })} ${date.getFullYear()}`}
                  className="react-calendar-custom"
                />
              </div>

              {/* End Calendar */}
              <div className="calendar-picker">
                <label className="calendar-label">End Date</label>
                <Calendar
                  onChange={handleEndChange}
                  value={endDate}
                  minDetail="year"
                  maxDetail="month"
                  prevLabel={null}
                  nextLabel={null}
                  navigationLabel={({ date }) => `${date.toLocaleString('default', { month: 'long' })} ${date.getFullYear()}`}
                  className="react-calendar-custom"
                />
              </div>
            </div>

            <div className="calendar-filter-button-container">
              <button className="calendar-filter-button" onClick={() => {
                setShowPicker(false);
                onFilter(startDate, endDate);
              }}>
                Apply
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CalendarRangePicker;
