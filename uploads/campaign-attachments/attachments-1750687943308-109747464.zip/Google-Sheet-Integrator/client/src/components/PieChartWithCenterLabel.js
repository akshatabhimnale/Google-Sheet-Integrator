import React, { useState, useMemo } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';

const PieChartWithCenterLabel = ({ campaigns = [] }) => {
  const [activeIndex, setActiveIndex] = useState(-1);

  const data = useMemo(() => {
    if (!campaigns || campaigns.length === 0) return [];

    const statusCounts = campaigns.reduce((acc, campaign) => {
      const status = campaign.Status || 'Unknown';
      acc[status] = (acc[status] || 0) + 1;
      return acc;
    }, {});

    return Object.entries(statusCounts).map(([status, count]) => ({
      name: status,
      value: count,
      percentage: ((count / campaigns.length) * 100).toFixed(1)
    }));
  }, [campaigns]);

  const COLORS = {
    'Live': '#10b981',
    'Completed': '#0ea5e9',
    'Internally Completed': '#0284c7',
    'Paused': '#f59e0b',
    'Flagged': '#ef4444',
    'Not Live': '#ef4444',
    'TBC': '#6b7280',
    'Unknown': '#9ca3af'
  };

  const getColor = (name) => COLORS[name] || '#9ca3af';

  const onPieEnter = (_, index) => {
    setActiveIndex(index);
  };

  const onPieLeave = () => {
    setActiveIndex(-1);
  };

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div style={{
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
          color: 'white',
          padding: '8px 12px',
          borderRadius: '6px',
          fontSize: '0.875rem',
          boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
          backdropFilter: 'blur(10px)'
        }}>
          <p style={{ margin: '0 0 4px 0', fontWeight: '600' }}>{data.name}</p>
          <p style={{ margin: 0, opacity: 0.9 }}>
            {data.value} campaigns ({data.percentage}%)
          </p>
        </div>
      );
    }
    return null;
  };

  const CustomLegend = ({ payload }) => {
    return (
      <div style={{ 
        display: 'flex', 
        flexDirection: 'column', 
        gap: '2px',
        fontSize: '0.65rem',
        marginTop: '8px',
        maxHeight: '70px',
        overflow: 'auto'
      }}>
        {payload.map((entry, index) => (
          <div 
            key={index} 
            style={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: '6px',
              padding: '1px 2px',
              borderRadius: '3px',
              backgroundColor: activeIndex === index ? '#f0f9ff' : 'transparent',
              transition: 'background-color 0.15s ease-in-out'
            }}
          >
            <div 
              style={{ 
                width: '8px', 
                height: '8px', 
                backgroundColor: entry.color, 
                borderRadius: '50%',
                border: '1px solid rgba(255, 255, 255, 0.2)',
                flexShrink: 0
              }} 
            />
            <span style={{ 
              color: '#374151',
              fontWeight: '500',
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis'
            }}>
              {entry.value} ({data.find(d => d.name === entry.value)?.value || 0})
            </span>
          </div>
        ))}
      </div>
    );
  };

  if (!data || data.length === 0) {
    return (
      <div style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height: '200px',
        color: '#6b7280',
        fontSize: '0.875rem'
      }}>
        <div style={{ fontSize: '3rem', marginBottom: '8px' }}>📊</div>
        <div>No campaign data available</div>
      </div>
    );
  }

  return (
    <div style={{ width: '100%', height: '100%', maxHeight: '250px' }}>
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="40%"
            innerRadius={30}
            outerRadius={65}
            paddingAngle={1}
            dataKey="value"
            onMouseEnter={onPieEnter}
            onMouseLeave={onPieLeave}
          >
            {data.map((entry, index) => (
              <Cell 
                key={`cell-${index}`} 
                fill={getColor(entry.name)}
                stroke={activeIndex === index ? '#fff' : 'none'}
                strokeWidth={activeIndex === index ? 2 : 0}
                style={{
                  filter: activeIndex === index ? 'brightness(1.1)' : 'none',
                  transition: 'all 0.15s ease-in-out'
                }}
              />
            ))}
          </Pie>
          <Tooltip content={<CustomTooltip />} />
          <Legend 
            content={<CustomLegend />}
            wrapperStyle={{ 
              paddingTop: '8px',
              fontSize: '0.7rem',
              maxHeight: '80px',
              overflow: 'hidden'
            }}
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

export default PieChartWithCenterLabel; 