import React, { useState } from 'react';
import { FaUser, FaLock, FaSignInAlt, FaEye, FaEyeSlash } from 'react-icons/fa';
import './UserLogin.css';

const UserLogin = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const backendUrl = process.env.REACT_APP_BACKEND_URL || 'http://localhost:5000';
      const response = await fetch(`${backendUrl}/api/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: email.trim(),
          password: password
        }),
      });

      const data = await response.json();

      if (data.success) {
        // Store token and user data
        localStorage.setItem('authToken', data.token);
        localStorage.setItem('currentUser', JSON.stringify(data.user));
        
        // Call onLogin with user data and token
        onLogin(data.user, data.token);
      } else {
        setError(data.message || 'Login failed');
      }
    } catch (error) {
      console.error('Login error:', error);
      setError('Network error. Please check your connection.');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoLogin = (demoEmail, demoPassword) => {
    setEmail(demoEmail);
    setPassword(demoPassword);
    setError('');
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <div className="login-header">
          <FaUser className="login-icon" />
          <h2>Login to Google Sheet Integrator</h2>
          <p>Enter your credentials to access the dashboard</p>
        </div>

        <form onSubmit={handleLogin} className="login-form">
          <div className="form-group">
            <label>Email</label>
            <div className="input-group">
              <FaUser className="input-icon" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                required
              />
            </div>
          </div>

          <div className="form-group">
            <label>Password</label>
            <div className="input-group">
              <FaLock className="input-icon" />
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                required
              />
              <button
                type="button"
                className="password-toggle"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <FaEyeSlash /> : <FaEye />}
              </button>
            </div>
          </div>

          {error && (
            <div className="error-message">
              {error}
            </div>
          )}

          <button type="submit" disabled={loading} className="login-btn">
            {loading ? (
              <>
                <div className="spinner"></div>
                Logging in...
              </>
            ) : (
              <>
                <FaSignInAlt />
                Login
              </>
            )}
          </button>
        </form>

        <div className="demo-users">
          <h3>Demo Accounts</h3>
          <p>Click on any account to auto-fill credentials</p>
          <div className="demo-user-grid">
            <div className="demo-user-card" onClick={() => handleDemoLogin('kapil@company.com', 'admin123')}>
              <div className="demo-avatar" style={{ backgroundColor: '#FF8A80' }}>K</div>
              <div className="demo-info">
                <strong>Kapil Admin</strong>
                <span>Admin</span>
                <small>kapil@company.com</small>
              </div>
            </div>
            <div className="demo-user-card" onClick={() => handleDemoLogin('john.doe@company.com', 'demo123')}>
              <div className="demo-avatar" style={{ backgroundColor: '#FF6B6B' }}>J</div>
              <div className="demo-info">
                <strong>John Doe</strong>
                <span>Project Manager</span>
                <small>john.doe@company.com</small>
              </div>
            </div>
            <div className="demo-user-card" onClick={() => handleDemoLogin('jane.smith@company.com', 'demo123')}>
              <div className="demo-avatar" style={{ backgroundColor: '#4ECDC4' }}>J</div>
              <div className="demo-info">
                <strong>Jane Smith</strong>
                <span>Marketing Lead</span>
                <small>jane.smith@company.com</small>
              </div>
            </div>
            <div className="demo-user-card" onClick={() => handleDemoLogin('mike.wilson@company.com', 'demo123')}>
              <div className="demo-avatar" style={{ backgroundColor: '#45B7D1' }}>M</div>
              <div className="demo-info">
                <strong>Mike Wilson</strong>
                <span>Data Analyst</span>
                <small>mike.wilson@company.com</small>
              </div>
            </div>
            <div className="demo-user-card" onClick={() => handleDemoLogin('sarah.brown@company.com', 'demo123')}>
              <div className="demo-avatar" style={{ backgroundColor: '#96CEB4' }}>S</div>
              <div className="demo-info">
                <strong>Sarah Brown</strong>
                <span>Operations</span>
                <small>sarah.brown@company.com</small>
              </div>
            </div>
            <div className="demo-user-card" onClick={() => handleDemoLogin('alex.johnson@company.com', 'demo123')}>
              <div className="demo-avatar" style={{ backgroundColor: '#FECA57' }}>A</div>
              <div className="demo-info">
                <strong>Alex Johnson</strong>
                <span>Quality Assurance</span>
                <small>alex.johnson@company.com</small>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserLogin; 