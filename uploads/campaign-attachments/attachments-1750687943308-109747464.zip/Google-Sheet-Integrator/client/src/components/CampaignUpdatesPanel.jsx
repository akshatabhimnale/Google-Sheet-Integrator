import React, { useState, useEffect, useRef } from 'react';
import io from 'socket.io-client';
import { 
  FaPaperPlane, 
  FaSpinner, 
  FaComments, 
  FaUser,
  FaClock,
  FaExclamationTriangle,
  FaRedo,
  FaCircle,
  FaPaperclip,
  FaImage,
  FaFilePdf,
  FaLink,
  FaDownload,
  FaTimes,
  FaCheckCircle
} from 'react-icons/fa';
import './CampaignUpdatesPanel.css';

const CampaignUpdatesPanel = ({ campaignId, campaignName }) => {
  const [updates, setUpdates] = useState([]);
  const [newUpdate, setNewUpdate] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [socket, setSocket] = useState(null);
  const [connected, setConnected] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [typingUsers, setTypingUsers] = useState([]);
  const [lastSeen, setLastSeen] = useState(new Date());
  const [currentUser, setCurrentUser] = useState(null);
  const [showAttachments, setShowAttachments] = useState(false);
  const [attachedFiles, setAttachedFiles] = useState([]);
  const [deliveredCount, setDeliveredCount] = useState(null);
  const [deliveredCountLoading, setDeliveredCountLoading] = useState(false);
  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);
  const typingTimeoutRef = useRef(null);
  const fileInputRef = useRef(null);

  // Get current user from auth context
  useEffect(() => {
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
    }
  }, []);

  useEffect(() => {
    if (campaignId && currentUser) {
      fetchUpdates();
      fetchDeliveredCount();
      initializeSocket();
    }

    return () => {
      if (socket) {
        socket.disconnect();
      }
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
    };
  }, [campaignId, currentUser]);

  useEffect(() => {
    scrollToBottom();
  }, [updates, typingUsers]);

  const initializeSocket = () => {
    const newSocket = io(process.env.REACT_APP_BACKEND_URL || 'http://localhost:5000', {
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionAttempts: 5,
      timeout: 20000
    });

    newSocket.on('connect', () => {
      console.log('🔗 Socket connected for campaign updates');
      setConnected(true);
      setError(null);
      newSocket.emit('join-campaign', campaignId);
    });

    newSocket.on('disconnect', () => {
      console.log('🔌 Socket disconnected');
      setConnected(false);
    });

    newSocket.on('new-campaign-update', (update) => {
      console.log('📨 New update received:', update);
      setUpdates(prev => [...prev, update]);
      setLastSeen(new Date());
    });

    newSocket.on('user-typing', (data) => {
      if (data.userId !== currentUser?.id) {
        setTypingUsers(prev => {
          const existing = prev.find(user => user.userId === data.userId);
          if (!existing) {
            return [...prev, data];
          }
          return prev;
        });
      }
    });

    newSocket.on('user-stopped-typing', (data) => {
      setTypingUsers(prev => prev.filter(user => user.userId !== data.userId));
    });

    newSocket.on('connect_error', (error) => {
      console.error('❌ Socket connection error:', error);
      setConnected(false);
      setError('Connection failed. Retrying...');
    });

    newSocket.on('reconnect', (attemptNumber) => {
      console.log(`🔄 Reconnected after ${attemptNumber} attempts`);
      setConnected(true);
      setError(null);
    });

    setSocket(newSocket);
  };

  const fetchUpdates = async () => {
    try {
      setLoading(true);
      setError(null);
      const backendUrl = process.env.REACT_APP_BACKEND_URL || 'http://localhost:5000';
      const token = localStorage.getItem('authToken');
      
      const response = await fetch(`${backendUrl}/api/campaigns/${campaignId}/updates`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        if (response.status === 500) {
          throw new Error('Server error. Please make sure the backend server is running.');
        } else if (response.status === 401) {
          throw new Error('Authentication failed. Please login again.');
        } else {
          throw new Error(`Failed to fetch updates: ${response.status}`);
        }
      }
      
      const data = await response.json();
      console.log('Fetched updates:', data.updates); // Debug log
      console.log('Current user for comparison:', currentUser); // Debug log
      setUpdates(data.updates || []);
      setLastSeen(new Date());
    } catch (err) {
      console.error('Error fetching updates:', err);
      
      // If it's a network error (server not running), use fallback
      if (err.message.includes('fetch') || err.message.includes('Failed to fetch')) {
        setError('Unable to connect to server. Please check if the backend is running on port 5000.');
        // Set some demo updates so the UI still works
        setUpdates([
          {
            _id: 'demo-1',
            campaignId: campaignId,
            message: 'This is a demo message. Backend server is not running.',
            timestamp: new Date().toISOString(),
            attachments: [],
            user: {
              id: 'demo-user',
              name: 'Demo User',
              email: 'demo@example.com',
              role: 'Demo',
              avatar: '#0ea5e9'
            }
          }
        ]);
      } else {
        setError(err.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const fetchDeliveredCount = async () => {
    try {
      setDeliveredCountLoading(true);
      const backendUrl = process.env.REACT_APP_BACKEND_URL || 'http://localhost:5000';
      const token = localStorage.getItem('authToken');
      
      const response = await fetch(`${backendUrl}/api/sheets/campaign-delivered-count?campaignCode=${campaignId}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        throw new Error(`Failed to fetch delivered count: ${response.status}`);
      }
      
      const data = await response.json();
      setDeliveredCount(data.data);
    } catch (err) {
      console.error('Error fetching delivered count:', err);
      setError(err.message);
    } finally {
      setDeliveredCountLoading(false);
    }
  };

  const submitUpdate = async (e) => {
    e.preventDefault();
    if ((!newUpdate.trim() && attachedFiles.length === 0) || submitting || !currentUser) return;

    try {
      setSubmitting(true);
      setError(null);

      // Stop typing indicator
      if (socket && connected) {
        socket.emit('stop-typing', { campaignId, userId: currentUser.id });
      }

      const formData = new FormData();
      formData.append('message', newUpdate.trim());

      // Add files to formData
      attachedFiles.forEach((file, index) => {
        formData.append('attachments', file);
      });

      const backendUrl = process.env.REACT_APP_BACKEND_URL || 'http://localhost:5000';
      const token = localStorage.getItem('authToken');
      
      const response = await fetch(`${backendUrl}/api/campaigns/${campaignId}/updates`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formData, // Don't set Content-Type, let browser set it for FormData
      });

      if (!response.ok) {
        if (response.status === 500) {
          throw new Error('Server error. Please make sure the backend server is running.');
        } else if (response.status === 401) {
          throw new Error('Authentication failed. Please login again.');
        } else {
          throw new Error(`Failed to submit update: ${response.status}`);
        }
      }

      const savedUpdate = await response.json();
      
      // Add update to local state if socket is not connected
      if (!connected) {
        setUpdates(prev => [...prev, savedUpdate.update || savedUpdate]);
      }
      
      setNewUpdate('');
      setAttachedFiles([]);
      setShowAttachments(false);
      
      // Reset textarea height
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    } catch (err) {
      console.error('Error submitting update:', err);
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleFileAttachment = (e) => {
    const files = Array.from(e.target.files);
    const validFiles = files.filter(file => {
      const isValidSize = file.size <= 10 * 1024 * 1024; // 10MB limit
      const isValidType = [
        'application/pdf',
        'image/jpeg',
        'image/png',
        'image/gif',
        'image/webp',
        'text/plain',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
      ].includes(file.type);
      
      return isValidSize && isValidType;
    });

    setAttachedFiles(prev => [...prev, ...validFiles]);
    setShowAttachments(false);
  };

  const removeAttachment = (index) => {
    setAttachedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // WhatsApp-like date formatting
  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInMs = now - date;
    const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));

    // If it's today
    if (diffInDays === 0) {
      return date.toLocaleTimeString([], { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
      });
    }
    
    // If it's yesterday
    if (diffInDays === 1) {
      return `Yesterday ${date.toLocaleTimeString([], { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
      })}`;
    }

    // If it's within the last week
    if (diffInDays < 7) {
      return `${date.toLocaleDateString([], { weekday: 'long' })} ${date.toLocaleTimeString([], { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
      })}`;
    }

    // If it's older than a week
    return date.toLocaleDateString([], { 
      month: 'short', 
      day: 'numeric',
      year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined,
      hour: '2-digit', 
      minute: '2-digit',
      hour12: true 
    });
  };

  // Group messages by date
  const groupMessagesByDate = (messages) => {
    const groups = {};
    messages.forEach(message => {
      const date = new Date(message.timestamp);
      const dateKey = date.toDateString();
      if (!groups[dateKey]) {
        groups[dateKey] = [];
      }
      groups[dateKey].push(message);
    });
    return groups;
  };

  const formatDateSeparator = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInDays = Math.floor((now - date) / (1000 * 60 * 60 * 24));

    if (diffInDays === 0) return 'Today';
    if (diffInDays === 1) return 'Yesterday';
    if (diffInDays < 7) return date.toLocaleDateString([], { weekday: 'long' });
    
    return date.toLocaleDateString([], { 
      month: 'long', 
      day: 'numeric',
      year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined
    });
  };

  const handleTextareaChange = (e) => {
    setNewUpdate(e.target.value);
    
    // Auto-resize textarea
    const textarea = e.target;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 150) + 'px';

    // Handle typing indicator
    if (socket && connected && currentUser) {
      if (e.target.value.trim() && !isTyping) {
        setIsTyping(true);
        socket.emit('typing', { 
          campaignId, 
          userId: currentUser.id, 
          userName: currentUser.name 
        });
      }

      // Clear existing timeout
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }

      // Set new timeout
      typingTimeoutRef.current = setTimeout(() => {
        setIsTyping(false);
        socket.emit('stop-typing', { campaignId, userId: currentUser.id });
      }, 2000);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      submitUpdate(e);
    }
  };

  const getRandomAvatar = (userName) => {
    const colors = [
      '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', 
      '#FECA57', '#FF9FF3', '#54A0FF', '#5F27CD',
      '#00D2D3', '#FF9F43', '#EE5A24', '#0088FE'
    ];
    const safeUserName = userName || 'Anonymous';
    const hash = safeUserName.split('').reduce((a, b) => a + b.charCodeAt(0), 0);
    return colors[hash % colors.length];
  };

  const getConnectionStatus = () => {
    if (connected) return { text: 'Live', color: 'connected' };
    if (loading) return { text: 'Connecting...', color: 'connecting' };
    return { text: 'Offline', color: 'disconnected' };
  };

  const getFileIcon = (fileType) => {
    if (fileType.startsWith('image/')) return <FaImage />;
    if (fileType === 'application/pdf') return <FaFilePdf />;
    return <FaPaperclip />;
  };

  const renderAttachment = (attachment) => {
    if (attachment.type?.startsWith('image/')) {
      return (
        <div className="attachment-preview image-preview">
          <img src={attachment.url} alt={attachment.name} />
          <div className="attachment-name">{attachment.name}</div>
        </div>
      );
    }

    return (
      <div className="attachment-preview file-preview">
        <div className="file-icon">
          {getFileIcon(attachment.type)}
        </div>
        <div className="file-info">
          <div className="file-name">{attachment.name}</div>
          <div className="file-size">{(attachment.size / 1024).toFixed(1)} KB</div>
        </div>
        <a href={attachment.url} download className="download-btn">
          <FaDownload />
        </a>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="updates-panel">
        <div className="updates-header">
          <div className="header-content">
            <div className="header-icon-wrapper">
              <FaComments className="header-icon" />
              <div className="header-glow"></div>
            </div>
            <div className="header-text">
              <h3>Campaign Updates</h3>
              <p className="campaign-name">Loading conversation...</p>
            </div>
          </div>
        </div>
        <div className="updates-loading">
          <FaSpinner className="loading-spinner" />
          <p>Loading updates...</p>
        </div>
      </div>
    );
  }

  const status = getConnectionStatus();
  const groupedMessages = groupMessagesByDate(updates);

  return (
    <div className="updates-panel">
      {/* Header */}
      <div className="updates-header">
        <div className="header-content">
          <div className="header-icon-wrapper">
            <FaComments className="header-icon" />
            <div className="header-glow"></div>
          </div>
          <div className="header-text">
            <h3>Campaign Updates</h3>
            <p className="campaign-name">{campaignName || 'Campaign Chat'}</p>
          </div>
          <div className="connection-indicator">
            <div className={`status-dot ${status.color}`}></div>
            <span className="status-text">{status.text}</span>
          </div>
        </div>
        <div className="header-actions">
          <button 
            onClick={fetchUpdates} 
            className="refresh-btn"
            disabled={loading}
            title="Refresh updates"
          >
            <FaRedo className={loading ? 'spinning' : ''} />
          </button>
        </div>
      </div>

      {/* Error Display */}
      {error && (
        <div className={`error-banner ${error.includes('server') || error.includes('connect') ? 'server-error' : ''}`}>
          <FaExclamationTriangle />
          <div className="error-content">
            <span className="error-message">{error}</span>
            {(error.includes('server') || error.includes('connect')) && (
              <div className="error-help">
                <p>To start the server:</p>
                <ol>
                  <li>Open a terminal in the project root</li>
                  <li>Run: <code>start-server.bat</code> (Windows) or <code>cd server && npm run dev</code></li>
                  <li>Wait for "Server running on port 5000" message</li>
                  <li>Click refresh button above</li>
                </ol>
              </div>
            )}
          </div>
          <button onClick={() => setError(null)} className="error-close">×</button>
        </div>
      )}

      {/* Messages Container */}
      <div className="messages-container">
        {updates.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">
              <FaComments />
            </div>
            <h4>No updates yet</h4>
            <p>Start the conversation by adding the first update about this campaign!</p>
          </div>
        ) : (
          <div className="messages-list">
            {Object.entries(groupedMessages).map(([dateString, dayMessages]) => (
              <div key={dateString}>
                <div className="date-separator">
                  <span>{formatDateSeparator(dateString)}</span>
                </div>
                {dayMessages.map((update, index) => (
                  <div key={update._id || index} className={`message-item ${update.user?.id === currentUser?.id ? 'own-message' : ''}`}>
                    {update.user?.id !== currentUser?.id && (
                      <div className="message-avatar">
                        <div 
                          className="avatar-circle"
                          style={{ backgroundColor: getRandomAvatar(update.user?.name || 'Anonymous') }}
                        >
                          {update.user?.name ? update.user.name.charAt(0).toUpperCase() : <FaUser />}
                        </div>
                        <div 
                          className="avatar-glow" 
                          style={{ backgroundColor: getRandomAvatar(update.user?.name || 'Anonymous') }}
                        ></div>
                      </div>
                    )}
                    <div className="message-content">
                      {update.user?.id !== currentUser?.id && (
                        <div className="message-header">
                          <span className="message-author">{update.user?.name || 'Anonymous'}</span>
                        </div>
                      )}
                      <div className="message-text">
                        {update.message && <div className="message-body">{update.message}</div>}
                        {update.attachments && update.attachments.length > 0 && (
                          <div className="message-attachments">
                            {update.attachments.map((attachment, idx) => (
                              <div key={idx}>
                                {renderAttachment(attachment)}
                              </div>
                            ))}
                          </div>
                        )}
                        <div className="message-timestamp">
                          <FaClock />
                          <span>{formatTimestamp(update.timestamp)}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ))}
            
            {/* Typing Indicator */}
            {typingUsers.length > 0 && (
              <div className="typing-indicator">
                <div className="typing-avatar">
                  <div className="typing-dots">
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>
                </div>
                <div className="typing-text">
                  {typingUsers.length === 1 
                    ? `${typingUsers[0].userName} is typing...`
                    : `${typingUsers.length} people are typing...`
                  }
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Input Form */}
      <div className="input-container">
        {/* Attached Files Preview */}
        {attachedFiles.length > 0 && (
          <div className="attached-files-preview">
            {attachedFiles.map((file, index) => (
              <div key={index} className="attached-file">
                <div className="file-icon">{getFileIcon(file.type)}</div>
                <span className="file-name">{file.name}</span>
                <button onClick={() => removeAttachment(index)} className="remove-file">
                  <FaTimes />
                </button>
              </div>
            ))}
          </div>
        )}

        <form onSubmit={submitUpdate} className="input-form">
          <div className="input-wrapper">
            <button
              type="button"
              className="attachment-btn"
              onClick={() => setShowAttachments(!showAttachments)}
              title="Attach file"
            >
              <FaPaperclip />
            </button>
            
            {showAttachments && (
              <div className="attachment-menu">
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  accept="image/*,.pdf,.doc,.docx,.txt"
                  onChange={handleFileAttachment}
                  style={{ display: 'none' }}
                />
                <button type="button" onClick={() => fileInputRef.current?.click()}>
                  <FaPaperclip /> Document
                </button>
                <button type="button" onClick={() => {
                  fileInputRef.current.accept = "image/*";
                  fileInputRef.current?.click();
                }}>
                  <FaImage /> Image
                </button>
              </div>
            )}

            <textarea
              ref={textareaRef}
              value={newUpdate}
              onChange={handleTextareaChange}
              onKeyPress={handleKeyPress}
              placeholder="Type a message..."
              className="message-input"
              disabled={submitting}
              rows="1"
            />
            <button
              type="submit"
              disabled={(!newUpdate.trim() && attachedFiles.length === 0) || submitting}
              className="send-button"
              title={submitting ? 'Sending...' : 'Send message (Enter)'}
            >
              {submitting ? (
                <FaSpinner className="spinning" />
              ) : (
                <FaPaperPlane />
              )}
            </button>
          </div>
        </form>
        
        {/* Connection Status Footer */}
        <div className="connection-footer">
          <div className="status-info">
            <FaCircle className={`status-icon ${connected ? 'connected' : 'disconnected'}`} />
            <span className="status-label">
              {connected ? 'Connected' : 'Reconnecting...'}
            </span>
          </div>
          <div className="user-info">
            Logged in as: {currentUser?.name || 'Guest'}
          </div>
        </div>
      </div>

      <div className="campaign-stats">
        {deliveredCountLoading ? (
          <div className="stat-loading">
            <FaSpinner className="spinner" />
            Loading stats...
          </div>
        ) : deliveredCount ? (
          <div className="stat-item">
            <FaCheckCircle className="stat-icon" />
            <span className="stat-label">Leads Sent:</span>
            <span className="stat-value">{deliveredCount.totalDelivered}</span>
          </div>
        ) : null}
      </div>
    </div>
  );
};

export default CampaignUpdatesPanel; 