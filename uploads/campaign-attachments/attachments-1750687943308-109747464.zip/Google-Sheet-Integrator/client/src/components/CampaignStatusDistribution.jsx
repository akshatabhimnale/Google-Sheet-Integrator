import React, { useState, useEffect, Suspense } from 'react';
import { FaChartPie, FaSpinner } from 'react-icons/fa';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import './CampaignStatusDistribution.css';

const CampaignStatusDistribution = ({ campaigns = [] }) => {
  const [statusData, setStatusData] = useState([]);
  const [activeIndex, setActiveIndex] = useState(-1);

  useEffect(() => {
    if (campaigns.length === 0) return;

    // Calculate status distribution
    const statusCounts = campaigns.reduce((acc, campaign) => {
      const status = campaign.Status || 'Unknown';
      acc[status] = (acc[status] || 0) + 1;
      return acc;
    }, {});

    // Convert to chart data
    const chartData = Object.entries(statusCounts).map(([status, count]) => ({
      name: status,
      value: count,
      percentage: ((count / campaigns.length) * 100).toFixed(1)
    }));

    setStatusData(chartData);
  }, [campaigns]);

  const COLORS = {
    'Live': '#10b981',
    'Completed': '#0ea5e9',
    'Internally Completed': '#0284c7',
    'Paused': '#f59e0b',
    'Flagged': '#ef4444',
    'Not Live': '#ef4444',
    'TBC': '#6b7280',
    'Unknown': '#9ca3af'
  };

  const getStatusColor = (status) => COLORS[status] || '#9ca3af';

  const onPieEnter = (_, index) => {
    setActiveIndex(index);
  };

  const onPieLeave = () => {
    setActiveIndex(-1);
  };

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="status-tooltip">
          <p className="tooltip-label">{data.name}</p>
          <p className="tooltip-value">
            {data.value} campaigns ({data.percentage}%)
          </p>
        </div>
      );
    }
    return null;
  };

  if (statusData.length === 0) {
    return (
      <div className="status-distribution-card">
        <div className="card-header">
          <FaChartPie />
          <span>Status Distribution</span>
        </div>
        <div className="no-data">
          <FaSpinner className="spinner" />
          <span>Loading data...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="status-distribution-card">
      <div className="card-header">
        <FaChartPie />
        <span>Status Distribution</span>
        <span className="total-count">({campaigns.length} total)</span>
      </div>
      
      <div className="distribution-content">
        <div className="chart-container">
          <ResponsiveContainer width="100%" height={120}>
            <PieChart>
              <Pie
                data={statusData}
                cx="50%"
                cy="50%"
                innerRadius={20}
                outerRadius={50}
                paddingAngle={2}
                dataKey="value"
                onMouseEnter={onPieEnter}
                onMouseLeave={onPieLeave}
              >
                {statusData.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={getStatusColor(entry.name)}
                    stroke={activeIndex === index ? '#fff' : 'none'}
                    strokeWidth={activeIndex === index ? 2 : 0}
                  />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </PieChart>
          </ResponsiveContainer>
        </div>
        
        <div className="legend-container">
          {statusData.map((entry, index) => (
            <div 
              key={entry.name} 
              className={`legend-item ${activeIndex === index ? 'active' : ''}`}
              onMouseEnter={() => setActiveIndex(index)}
              onMouseLeave={() => setActiveIndex(-1)}
            >
              <div 
                className="legend-color" 
                style={{ backgroundColor: getStatusColor(entry.name) }}
              ></div>
              <div className="legend-info">
                <span className="legend-name">{entry.name}</span>
                <span className="legend-value">{entry.value}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CampaignStatusDistribution; 