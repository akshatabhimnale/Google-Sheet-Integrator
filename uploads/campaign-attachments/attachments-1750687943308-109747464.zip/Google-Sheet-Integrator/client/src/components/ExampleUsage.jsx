import React from 'react';
import CampaignUpdatesPanel from './CampaignUpdatesPanel';

// Example 1: Usage in Campaign Details Page
const CampaignDetailsWithUpdates = ({ campaign }) => {
  return (
    <div style={{ 
      display: 'grid', 
      gridTemplateColumns: '1fr 400px', 
      gap: '1.5rem', 
      height: '100vh',
      padding: '1.5rem'
    }}>
      {/* Main Campaign Details */}
      <div style={{ 
        background: 'white', 
        borderRadius: '1rem', 
        padding: '2rem',
        boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)'
      }}>
        <h1>Campaign: {campaign?.name}</h1>
        <p>ITL: {campaign?.ITL}</p>
        <p>Status: {campaign?.Status}</p>
        {/* Other campaign details */}
      </div>
      
      {/* Updates Panel */}
      <CampaignUpdatesPanel 
        campaignId={campaign?.ITL} 
        campaignName={campaign?.name}
      />
    </div>
  );
};

// Example 2: Usage in Modal
const UpdatesModal = ({ isOpen, onClose, campaign }) => {
  if (!isOpen) return null;
  
  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1000
    }}>
      <div style={{
        width: '600px',
        height: '700px',
        backgroundColor: 'white',
        borderRadius: '1rem',
        overflow: 'hidden',
        position: 'relative'
      }}>
        <button 
          onClick={onClose}
          style={{
            position: 'absolute',
            top: '1rem',
            right: '1rem',
            background: 'none',
            border: 'none',
            fontSize: '1.5rem',
            cursor: 'pointer',
            zIndex: 10
          }}
        >
          ×
        </button>
        <CampaignUpdatesPanel 
          campaignId={campaign?.ITL} 
          campaignName={campaign?.name}
        />
      </div>
    </div>
  );
};

// Example 3: Usage in Sidebar
const DashboardWithUpdatesSidebar = ({ selectedCampaign }) => {
  return (
    <div style={{
      display: 'flex',
      height: '100vh'
    }}>
      {/* Main Dashboard */}
      <div style={{ flex: 1, padding: '1.5rem' }}>
        <h1>Dashboard</h1>
        {/* Dashboard content */}
      </div>
      
      {/* Updates Sidebar */}
      {selectedCampaign && (
        <div style={{ 
          width: '400px', 
          borderLeft: '1px solid #e2e8f0',
          background: '#f8fafc'
        }}>
          <CampaignUpdatesPanel 
            campaignId={selectedCampaign.ITL} 
            campaignName={selectedCampaign.name}
          />
        </div>
      )}
    </div>
  );
};

// Example 4: Standalone Page
const UpdatesPage = ({ campaignId, campaignName }) => {
  return (
    <div style={{
      maxWidth: '800px',
      margin: '0 auto',
      padding: '2rem',
      height: '100vh'
    }}>
      <CampaignUpdatesPanel 
        campaignId={campaignId} 
        campaignName={campaignName}
      />
    </div>
  );
};

export { 
  CampaignDetailsWithUpdates, 
  UpdatesModal, 
  DashboardWithUpdatesSidebar, 
  UpdatesPage 
}; 