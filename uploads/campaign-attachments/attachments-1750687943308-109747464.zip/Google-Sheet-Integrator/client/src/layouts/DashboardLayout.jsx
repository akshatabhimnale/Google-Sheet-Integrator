import React, { useState } from 'react';
import { 
  FaHome, 
  FaChartBar, 
  FaCog, 
  FaUsers, 
  FaBell, 
  FaSearch
} from 'react-icons/fa';
import { useAuth } from '../contexts/AuthContext';
import ProfileDropdown from '../components/ProfileDropdown';
import DashboardTable from '../pages/DashboardTable';
import CampaignDetails from '../pages/CampaignDetails';
import './DashboardLayout.css';

const DashboardLayout = () => {
  const { currentUser } = useAuth();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const [campaigns, setCampaigns] = useState([]);

  const handleCampaignSelect = (campaign) => {
    setSelectedCampaign(campaign);
  };

  const handleCloseCampaignDetails = () => {
    setSelectedCampaign(null);
  };

  const handleCampaignsUpdate = (newCampaigns) => {
    setCampaigns(newCampaigns);
  };

  if (selectedCampaign) {
    return (
      <CampaignDetails 
        campaign={selectedCampaign} 
        onClose={handleCloseCampaignDetails}
        allCampaigns={campaigns}
      />
    );
  }

  return (
    <div className={`dashboard-layout ${isSidebarOpen ? 'sidebar-open' : 'sidebar-closed'}`}>
    {/* Floating Background Elements */}
    <div className="floating-elements">
      <div className="floating-circle circle-1"></div>
      <div className="floating-circle circle-2"></div>
      <div className="floating-circle circle-3"></div>
    </div>
  
    {/* Header */}
    <header className="dashboard-header">
      <div className="header-left">
        <button 
          className="menu-toggle-btn"
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
        >
          ☰
        </button>
        <div className="logo">
          <FaChartBar className="logo-icon" />
          <span className="logo-text">GSI Dashboard</span>
        </div>
      </div>
  
      <div className="header-right">
        {/* New Profile Dropdown */}
        <ProfileDropdown />
      </div>
    </header>
  
    {/* Sidebar */}
    <aside className={`dashboard-sidebar`}>
      <nav className="sidebar-nav">
        <button className="nav-item active">
          <FaHome className="nav-icon" />
          <span className="nav-text">Dashboard</span>
        </button>
        <button className="nav-item">
          <FaChartBar className="nav-icon" />
          <span className="nav-text">Analytics</span>
        </button>
        <button className="nav-item">
          <FaUsers className="nav-icon" />
          <span className="nav-text">Teams</span>
        </button>
        <button className="nav-item">
          <FaCog className="nav-icon" />
          <span className="nav-text">Settings</span>
        </button>
      </nav>
    </aside>
  
    {/* Main Content */}
    <main className="dashboard-main">
      <DashboardTable 
        onCampaignSelect={handleCampaignSelect}
        onCampaignsUpdate={handleCampaignsUpdate}
      />
    </main>
  </div>
  
  );
};

export default DashboardLayout;
