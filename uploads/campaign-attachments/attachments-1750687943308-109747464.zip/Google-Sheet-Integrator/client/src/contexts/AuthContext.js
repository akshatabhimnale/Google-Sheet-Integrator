import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [token, setToken] = useState(null);

  // Initialize auth state on app start - simplified without backend validation
  useEffect(() => {
    const initializeAuth = () => {
      try {
        const savedToken = localStorage.getItem('authToken');
        const savedUser = localStorage.getItem('currentUser');

        if (savedToken && savedUser) {
          setToken(savedToken);
          setCurrentUser(JSON.parse(savedUser));
        }
      } catch (error) {
        console.error('Error initializing auth:', error);
        // Clear corrupted data
        localStorage.removeItem('authToken');
        localStorage.removeItem('currentUser');
        setToken(null);
        setCurrentUser(null);
      } finally {
        setLoading(false);
      }
    };

    initializeAuth();
  }, []);

  const login = (userData, authToken) => {
    // Store both user data and token
    if (authToken) {
      setToken(authToken);
      localStorage.setItem('authToken', authToken);
    }
    
    setCurrentUser(userData);
    localStorage.setItem('currentUser', JSON.stringify(userData));
    setLoading(false);
  };

  const logout = async () => {
    try {
      // Call logout API if needed
      const backendUrl = process.env.REACT_APP_BACKEND_URL || 'http://localhost:5000';
      const currentToken = token || localStorage.getItem('authToken');
      
      if (currentToken) {
        await fetch(`${backendUrl}/api/auth/logout`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${currentToken}`,
            'Content-Type': 'application/json',
          },
        });
      }
    } catch (error) {
      console.error('Logout API error:', error);
      // Continue with logout even if API fails
    } finally {
      // Clear local storage
      localStorage.removeItem('authToken');
      localStorage.removeItem('currentUser');
      
      // Clear state
      setCurrentUser(null);
      setToken(null);
    }
  };

  const getAuthHeaders = () => {
    const currentToken = token || localStorage.getItem('authToken');
    return currentToken ? {
      'Authorization': `Bearer ${currentToken}`,
      'Content-Type': 'application/json',
    } : {
      'Content-Type': 'application/json',
    };
  };

  const value = {
    currentUser,
    token,
    loading,
    login,
    logout,
    getAuthHeaders,
    isAuthenticated: !!currentUser
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}; 