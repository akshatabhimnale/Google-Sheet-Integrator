import React, { useState } from 'react';
import axios from 'axios';

const ExcelUploader = () => {
  const [file, setFile] = useState(null);
  const [reportType, setReportType] = useState('single');
  const [status, setStatus] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const MAX_RETRIES = 3;

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      // Validate file type
      if (!selectedFile.name.match(/\.(xlsx|xls|csv)$/i)) {
        setStatus('❌ Please select a valid file (.xlsx, .xls, or .csv)');
        setFile(null);
        return;
      }
      // Validate file size (10MB max)
      if (selectedFile.size > 10 * 1024 * 1024) {
        setStatus('❌ File size too large. Maximum size is 10MB.');
        setFile(null);
        return;
      }
      setFile(selectedFile);
      setStatus('');
    }
  };

  const handleUpload = async () => {
    if (!file) {
      setStatus('❌ Please select a file');
      return;
    }

    setIsUploading(true);
    setStatus('Uploading...');

    const formData = new FormData();
    formData.append('file', file);

    const endpoint =
      reportType === 'single'
        ? 'http://localhost:5000/api/sheets/upload-lead-report'
        : 'http://localhost:5000/api/sheets/upload-merged-lead-report';

    try {
      console.log('Uploading file:', {
        name: file.name,
        type: file.type,
        size: file.size
      });

      const response = await axios.post(endpoint, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        onUploadProgress: (progressEvent) => {
          const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
          setStatus(`Uploading... ${percentCompleted}%`);
        },
        timeout: 30000, // 30 second timeout
      });

      if (response.data.stats) {
        const { stats } = response.data;
        setStatus(
          `✅ Upload successful!\n` +
          `Total Rows: ${stats?.totalRows || 0}\n` +
          `Processed: ${stats?.processedRows || 0}\n` +
          `Skipped: ${stats?.skippedRows || 0}\n` +
          `Accepted: ${stats?.accepted?.total || 0} (Modified: ${stats?.accepted?.modified || 0}, New: ${stats?.accepted?.inserted || 0})\n` +
          `Rejected: ${stats?.rejected?.total || 0} (Modified: ${stats?.rejected?.modified || 0}, New: ${stats?.rejected?.inserted || 0})`
        );
      } else {
        setStatus('✅ Upload successful!');
      }
      
      // Reset states after successful upload
      setFile(null);
      setRetryCount(0);
    } catch (error) {
      console.error('Upload error details:', {
        message: error.message,
        response: error.response?.data,
        status: error.response?.status,
        headers: error.response?.headers
      });
      
      if (retryCount < MAX_RETRIES && 
          (error.code === 'ERR_UPLOAD_FILE_CHANGED' || 
           error.message.includes('Network Error'))) {
        setRetryCount(prev => prev + 1);
        setStatus(`❌ Upload failed. Retrying... (${retryCount + 1}/${MAX_RETRIES})`);
        setTimeout(handleUpload, 1000); // Retry after 1 second
      } else {
        let errorMessage = '❌ Upload failed: ';
        if (error.response?.data?.error) {
          errorMessage += error.response.data.error;
        } else if (error.response?.data?.message) {
          errorMessage += error.response.data.message;
        } else {
          errorMessage += error.message;
        }
        setStatus(errorMessage + '\nPlease try again.');
      }
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.heading}>Lead Report Uploader</h1>

      <div style={styles.dropdownContainer}>
        <label style={styles.label}>Select Report Type:</label>
        <select
          value={reportType}
          onChange={(e) => setReportType(e.target.value)}
          style={styles.dropdown}
          disabled={isUploading}
        >
          <option value="single">Single Campaign Lead Report</option>
          <option value="merged">Merged Lead Report</option>
        </select>
      </div>

      <div style={styles.uploadSection}>
        <input
          type="file"
          accept=".xlsx,.xls,.csv"
          onChange={handleFileChange}
          style={styles.input}
          disabled={isUploading}
        />
        <button 
          onClick={handleUpload} 
          style={{
            ...styles.button,
            opacity: isUploading ? 0.7 : 1,
            cursor: isUploading ? 'not-allowed' : 'pointer'
          }}
          disabled={isUploading || !file}
        >
          {isUploading ? 'Uploading...' : 'Upload'}
        </button>
      </div>

      <pre style={styles.status}>{status}</pre>
    </div>
  );
};

const styles = {
  container: {
    fontFamily: 'Segoe UI, sans-serif',
    padding: '2rem',
    maxWidth: '500px',
    margin: '3rem auto',
    backgroundColor: '#f9f9f9',
    borderRadius: '12px',
    boxShadow: '0 0 10px rgba(0,0,0,0.1)'
  },
  heading: {
    textAlign: 'center',
    marginBottom: '1.5rem',
    color: '#333'
  },
  dropdownContainer: {
    marginBottom: '1.2rem'
  },
  label: {
    fontWeight: '600',
    display: 'block',
    marginBottom: '0.5rem'
  },
  dropdown: {
    padding: '0.5rem',
    width: '100%',
    fontSize: '1rem',
    borderRadius: '6px',
    border: '1px solid #ccc'
  },
  uploadSection: {
    display: 'flex',
    alignItems: 'center',
    gap: '1rem'
  },
  input: {
    flex: '1'
  },
  button: {
    padding: '0.6rem 1rem',
    backgroundColor: '#4CAF50',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    transition: 'opacity 0.3s ease'
  },
  status: {
    marginTop: '1rem',
    fontWeight: '500',
    whiteSpace: 'pre-wrap',
    wordBreak: 'break-word'
  }
};

export default ExcelUploader;
