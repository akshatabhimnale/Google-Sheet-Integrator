import React from 'react';
import ExcelUploader from './components/ExcelUploader';

function App() {
  return (
    <div>
      <ExcelUploader />
    </div>
  );
}

export default App;
